"""Package the Rev C presentation with its unchanged mechanical baseline."""
from pathlib import Path
import zipfile
R=Path(__file__).resolve().parent.parent
required=['DBA_Interactive.html','DBA_Design_Package_RevC.pdf','DBA_Product_Overview_RevC.pptx','DBA_Annotated_Views_RevB.pdf','README.txt','README_RevC.txt']
for name in required:
 if not (R/name).is_file():raise FileNotFoundError(name)
with zipfile.ZipFile(R/'DBA_Package_RevC.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in required+['dba_cad.py','render.py','drawing_sheet.py']:
  z.write(R/name,name)
 for folder in ['cad','drawings','renders','legacy']:
  for p in sorted((R/folder).rglob('*')):
   if p.is_file() and not p.name.startswith('.'):z.write(p,p.relative_to(R))
 z.write(R/'DBA_Design_Package_RevA.pdf','legacy/DBA_Design_Package_RevA.pdf')
 z.write(R/'DBA_Design_Package_RevB.pdf','legacy/DBA_Design_Package_RevB.pdf')
 for p in sorted((R/'presentation').iterdir()):
  if p.is_file() and p.suffix in {'.html','.css','.js','.py','.json','.svg'} and p.name not in {'RevA_Interactive.original.html','sim.js'}:
   z.write(p,p.relative_to(R))
 z.write(R/'presentation/deck-build/build.mjs','presentation/deck-build/build.mjs')
print('Created DBA_Package_RevC.zip')
