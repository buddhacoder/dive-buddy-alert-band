(function(){
'use strict';const canvas=document.getElementById('heroCanvas'),fallback=document.getElementById('heroFallback');let renderer;
try{if(!window.THREE)throw Error('3D unavailable');renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true});}catch(e){canvas.hidden=true;document.querySelectorAll('.hero-tools button,#heroDisplay').forEach(b=>b.disabled=true);document.querySelector('.hero-figure figcaption').textContent='Original exterior render · 3D display study unavailable';return;}
renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.95;
const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(31,1,.1,1500);camera.up.set(0,0,1);const group=new THREE.Group();scene.add(group);scene.add(new THREE.HemisphereLight(0xe4f4ff,0x344554,.8));
for(const [x,y,z,color,power] of [[-90,-130,150,0xf4f8ff,1.1],[120,65,110,0xa9deeb,.85],[0,120,-20,0xc1cdd6,.6]]){const l=new THREE.DirectionalLight(color,power);l.position.set(x,y,z);scene.add(l);}
// A surface-material study only: original coordinates and mesh payloads are unchanged.
const displayCanvas=document.createElement('canvas');displayCanvas.width=512;displayCanvas.height=512;
const displayContext=displayCanvas.getContext('2d'),displayTexture=new THREE.CanvasTexture(displayCanvas);
displayTexture.encoding=THREE.sRGBEncoding;
const displayEnabled={value:1};
function paintDisplay(detail={}){
 const c=displayContext;c.fillStyle='#071115';c.fillRect(0,0,512,512);
 c.strokeStyle='#709699';c.lineWidth=5;c.strokeRect(10,10,492,492);
 c.textAlign='center';c.fillStyle='#b2d8dc';c.font='500 48px sans-serif';c.fillText((detail.label||'BUDDY').toUpperCase(),256,91);
 const value=detail.value||'READY';c.fillStyle='#f2fcff';c.font=`600 ${value.length>6?65:92}px sans-serif`;c.fillText(value,256,286);
 c.fillStyle='#b2d8dc';c.font='500 35px sans-serif';const sub=(detail.subline||'PAIRED').slice(0,21);c.fillText(sub,256,403);
 displayTexture.needsUpdate=true;
}
paintDisplay();
const M=window.DBA_MODEL;M.parts.filter((_,i)=>[0,1,9,10].includes(i)).forEach(p=>{const a=new Int16Array(Uint8Array.from(atob(p.data),c=>c.charCodeAt(0)).buffer),v=new Float32Array(a.length);for(let i=0;i<v.length;i++)v[i]=a[i]/32767*M.scale;const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(v,3));DBA_smoothNormals(g);const isBand=p.id.startsWith('01'),isButton=p.id.startsWith('11');const mat=new THREE.MeshStandardMaterial({color:new THREE.Color(isBand?'#303942':isButton?'#d84934':'#677781').convertSRGBToLinear(),roughness:isBand?.8:isButton?.58:.38,metalness:isBand||isButton?0:.18});if(p.id.startsWith('10')){
 mat.onBeforeCompile=shader=>{
  shader.uniforms.dbaScreen={value:displayTexture};shader.uniforms.dbaShow=displayEnabled;
  shader.vertexShader='varying vec3 vDbaPosition;\n'+shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvDbaPosition=position;');
  shader.fragmentShader='uniform sampler2D dbaScreen;\nuniform float dbaShow;\nvarying vec3 vDbaPosition;\n'+shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   vec2 dbaUV=(vDbaPosition.xy-vec2(-15.,-7.))/vec2(14.,14.);
   float dbaMask=step(0.,dbaUV.x)*step(dbaUV.x,1.)*step(0.,dbaUV.y)*step(dbaUV.y,1.)*step(40.12,vDbaPosition.z)*dbaShow;
   vec3 dbaColor=texture2D(dbaScreen,dbaUV).rgb;
   diffuseColor.rgb=mix(diffuseColor.rgb,vec3(0.015),dbaMask);
   totalEmissiveRadiance+=dbaColor*dbaMask*.85;`);
 };
}
group.add(new THREE.Mesh(g,mat));});
let theta=-.93,phi=1.09,radius=206,targetZ=0,dirty=true,visible=true,pointers=new Map(),pinch=0;const original={theta,phi,radius,targetZ};
window.addEventListener('dba:display',e=>{paintDisplay(e.detail);dirty=true;});
const displayToggle=document.getElementById('heroDisplay');displayToggle.onclick=()=>{displayEnabled.value=1-displayEnabled.value;displayToggle.setAttribute('aria-pressed',String(!!displayEnabled.value));displayToggle.textContent=displayEnabled.value?'Display study on':'Original enclosure';dirty=true;};
function reset(){({theta,phi,radius,targetZ}=original);dirty=true;}function rotate(d){theta+=d;dirty=true;}
function resize(){const w=canvas.clientWidth,h=canvas.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();dirty=true;}new ResizeObserver(resize).observe(canvas);new IntersectionObserver(es=>{visible=es[0].isIntersecting;if(visible)dirty=true;}).observe(canvas);
canvas.onpointerdown=e=>{canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,[e.clientX,e.clientY]);if(pointers.size===2){const a=[...pointers.values()];pinch=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]);}};
canvas.onpointermove=e=>{if(!pointers.has(e.pointerId))return;const old=pointers.get(e.pointerId);pointers.set(e.pointerId,[e.clientX,e.clientY]);if(pointers.size===2){const a=[...pointers.values()],d=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]);radius=Math.max(70,Math.min(300,radius*pinch/d));pinch=d;}else{theta-=(e.clientX-old[0])*.008;phi=Math.max(.15,Math.min(2.95,phi+(e.clientY-old[1])*.008));}dirty=true;};
canvas.onpointerup=canvas.onpointercancel=e=>pointers.delete(e.pointerId);canvas.addEventListener('wheel',e=>{if(!canvas.matches(':focus'))return;e.preventDefault();radius=Math.max(70,Math.min(300,radius*(1+e.deltaY*.001)));dirty=true;},{passive:false});
canvas.onkeydown=e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','-','Home'].includes(e.key)){e.preventDefault();if(e.key==='ArrowLeft')theta-=.16;if(e.key==='ArrowRight')theta+=.16;if(e.key==='ArrowUp')phi=Math.max(.15,phi-.12);if(e.key==='ArrowDown')phi=Math.min(2.95,phi+.12);if(e.key==='+')radius=Math.max(70,radius-12);if(e.key==='-')radius=Math.min(300,radius+12);if(e.key==='Home')reset();dirty=true;}};
document.getElementById('heroLeft').onclick=()=>rotate(-.3);document.getElementById('heroRight').onclick=()=>rotate(.3);document.getElementById('heroReset').onclick=reset;document.getElementById('heroDetail').onclick=()=>{targetZ=39;radius=88;phi=.26;theta=-Math.PI/2;dirty=true;};
function frame(){requestAnimationFrame(frame);if(!dirty||!visible)return;dirty=false;camera.position.set(radius*Math.sin(phi)*Math.cos(theta),radius*Math.sin(phi)*Math.sin(theta),targetZ+radius*Math.cos(phi));camera.lookAt(0,0,targetZ);renderer.render(scene,camera);fallback.hidden=true;}resize();frame();window.DBA_HERO={get theta(){return theta;},get phi(){return phi;},parts:group.children.length,get displayVisible(){return !!displayEnabled.value;}};
})();
