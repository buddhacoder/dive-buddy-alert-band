from pathlib import Path
import json,base64,html,re
R=Path(__file__).resolve().parent.parent
P=R/'presentation'
req=json.loads((P/'requirements.json').read_text())
model=(P/'model.original.js').read_text()
# Descriptions are rendered from the reviewed viewer metadata, not stale Rev A claims.
model=re.sub(r'"desc":\s*"(?:[^"\\]|\\.)*"', '"desc": "Concept component; see the reviewed part notes below."', model)
img=lambda name:'data:image/png;base64,'+base64.b64encode((R/'renders'/name).read_bytes()).decode()
rows=''.join('<tr><th scope="row">'+html.escape(x[0])+'</th><td><span class="status">'+html.escape(x[1])+'</span><p>'+html.escape(x[2])+'</p></td><td>'+html.escape(x[4])+'<small>'+html.escape(x[3])+'</small></td></tr>' for x in req)
drawings=''.join('<figure><img src="data:image/svg+xml;base64,'+base64.b64encode((P/(name+'.svg')).read_bytes()).decode()+'" alt="'+alt+'"><figcaption>'+caption+'</figcaption></figure>' for name,alt,caption in [
('module','Module plan: 38 by 28 millimeters, nominal 13 millimeter button opening.','Module plan · nominal source dimensions · mm'),
('band','Band front: 62 millimeter opening, 70 millimeter outside diameter, 84.7 millimeter assembly height.','Band front · includes module and button · mm'),
('section','Module side section showing internal layout and unresolved cap clearance.','Module section · schematic layout, unresolved interference · mm')])
template=(P/'page.html').read_text()
for a,b in {'__REQ_ROWS__':rows,'__DRAWINGS__':drawings,'__HERO__':img('hero_assembled.png'),'__MODEL__':model,'__JS__':'\n'.join((P/n).read_text() for n in ['atmosphere.js','hero.js','viewer.js','sim.js']),'__CSS__':(P/'style.css').read_text()}.items():template=template.replace(a,b)
(R/'DBA_Interactive.html').write_text(template)
print('Built DBA_Interactive.html; embedded original model and annotated drawings')
