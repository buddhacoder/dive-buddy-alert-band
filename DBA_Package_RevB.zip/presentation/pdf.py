from pathlib import Path
import json,html
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.utils import ImageReader
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF
R=Path(__file__).resolve().parent.parent; P=R/'presentation'; O=R/'output/pdf';O.mkdir(parents=True,exist_ok=True)
W,H=595.28,841.89; margin=44; ink='#172d40';muted='#526779';blue='#21638f'; red='#ab3928'
normal=ParagraphStyle('body',fontName='Helvetica',fontSize=10.5,leading=16,textColor=HexColor(ink),spaceAfter=10)
small=ParagraphStyle('small',parent=normal,fontSize=8.8,leading=12.5)
def ascii_text(s):
 for a,b in [('→',' to '),('–','-'),('—',' - '),('’',"'"),('“','"'),('”','"'),('×',' x '),('≈','approximately '),('−','-')]:s=s.replace(a,b)
 return s
class Doc:
 def __init__(self,name):self.c=canvas.Canvas(str(O/name),pagesize=(W,H));self.n=0;self.y=0;self.c.setTitle('Dive Buddy Alert Band | '+name.replace('_',' '));self.c.setAuthor('Concept by Rafael; presentation revision B')
 def page(self,title,sub=''):
  if self.n:self.c.showPage()
  self.n+=1; c=self.c;c.setFillColor(HexColor('#07111c'));c.rect(0,H-20,W,20,fill=1,stroke=0);c.setFillColor(HexColor(muted));c.setFont('Helvetica',9);c.drawString(margin,H-44,'DIVE BUDDY ALERT BAND / PRESENTATION REV B')
  self.y=H-74;self.para(title,24,28,bold=True);self.y-=6
  if sub:self.para(sub,10,15,color=muted)
  c.setStrokeColor(HexColor('#cfdae2'));c.line(margin,40,W-margin,40);c.setFont('Helvetica',8);c.setFillColor(HexColor(muted));c.drawString(margin,27,'Concept by Rafael | Concept only; no manufacturing release | September 2026');c.drawRightString(W-margin,27,str(self.n))
 def para(self,s,size=10.5,leading=16,bold=False,color=ink):
  st=ParagraphStyle('p',parent=normal,fontSize=size,leading=leading,textColor=HexColor(color),fontName='Helvetica-Bold' if bold else 'Helvetica')
  p=Paragraph(ascii_text(s),st);_,h=p.wrap(W-2*margin,1000);p.drawOn(self.c,margin,self.y-h);self.y-=h+12
  if self.y<55:raise ValueError(f'Page {self.n} overflow at {s[:60]}')
 def image(self,path,maxh=280):
  ir=ImageReader(str(path));w,h=ir.getSize();ratio=min((W-2*margin)/w,maxh/h);dw,dh=w*ratio,h*ratio;self.c.drawImage(ir,margin+(W-2*margin-dw)/2,self.y-dh,width=dw,height=dh,mask='auto');self.y-=dh+16
 def svg(self,name,maxh=300):
  d=svg2rlg(str(P/(name+'.svg')));ratio=min((W-2*margin)/d.width,maxh/d.height);d.scale(ratio,ratio);h=d.height*ratio;renderPDF.draw(d,self.c,margin+(W-2*margin-d.width*ratio)/2,self.y-h);self.y-=h+15
 def save(self):self.c.save();print(self.n,'pages created')
d=Doc('DBA_Design_Package_RevB.pdf')
d.page('Dive Buddy Alert Band','Underwater buddy communication.')
d.image(R/'renders/hero_assembled.png',265)
d.para('Paired calls. Tactile distance feedback.',18,24,True)
d.para('A proposed slip-on silicone wristband calls a paired diver underwater, then turns a measured gap into a changing vibration cadence. One wrist transducer provides <b>distance, not direction</b>.')
d.para('Product concept',13,18,True)
d.para('A separate wristband uses one top-mounted button and a haptic motor for paired calls and distance feedback. Recreational buddy pairs are the intended users; instructors and dive shops are potential sales channels. Customer demand remains unvalidated.')
d.para('An aid to buddy procedures, never a safety guarantee. The concept cannot identify a safe route, confirm visual contact or ensure reunion.',11,16,True,red)
d.page('User interaction','Proposed pairing, call, ranging and stop sequence.')
for title,body in [
('1 / Pair on the surface','Hold both buttons for 3 seconds; synchronized LEDs are the proposed pairing indication. A shared 16-bit code is an assumption, not proof of cross-pair isolation.'),
('2 / A calls B','A short press requests three strong buzzes and a blinking LED on B. Packet acknowledgement and human acknowledgement are different; delivery feedback and retries remain undefined.'),
('3 / A requests ranging','A 1-second hold starts the proposed exchange. Both bands participate in messaging; A receives the changing cadence. B\'s ongoing indication is still an open interaction decision.'),
('4 / Stop','One press on either band requests Stop. Rev A proposes a five-minute timeout and a one-second burst then stop below 2 m. Neither proximity nor an automatic stop confirms reunion.'),
('5 / Charge','Place the bands on an inductive dock. No band charging port. Dock power input, alignment, thermal design and completion indication need definition.')]:
 d.para(title,14,18,True);d.para(body)
d.para('Use case',14,18,True)
d.para('A buddy facing away receives a paired tactile call. During ranging, the caller receives a cadence that changes with the estimated separation. The proposed product combines addressed attention and tactile distance feedback in a standalone wristband.')
d.page('Distance feedback','Distance feedback is not a directional navigation display.')
for a,b in [('Over 15 m / valid reply','One pulse every 4 seconds.'),('10-15 m','One pulse every 2 seconds.'),('5-10 m','One pulse every second.'),('2-5 m','A double pulse every 0.5 seconds.'),('Below 2 m','One-second burst, then stop. Near does not mean found.'),('No reply','Distance unknown. The revised demo suppresses proximity pulses; the device\'s distinct lost-link indication is an open requirement.')]:d.para('<b>'+a+'</b> - '+b)
d.para('The acoustic exchange',15,20,True)
d.para('Approximately 65 kHz ultrasonic two-way time-of-flight. Proposed distance calculation: <b>d = (round-trip time - fixed reply delay) x sound speed / 2</b>. Using 1,500 m/s and an assumed 2 ms reply delay, 20 m corresponds to about 26.7 ms propagation round trip and 28.7 ms total exchange time.')
d.para('20 m range, approximately ±0.3 m distance performance and nominal 1 Hz exchange are proposed targets or assumptions, not demonstrated results. Timing resolution alone does not establish ranging accuracy. Body shadowing, multipath, orientation and environmental variation remain unresolved.')
d.para('Demonstrator behavior',15,20,True)
d.para('The web page provides Call, Start ranging, Stop, a simulated-distance control and a reply toggle. Its 20 m cutoff is an illustrative envelope, not a propagation model. Optional phone vibration illustrates cadence only. Production boundary hysteresis, actuator waveforms and user perceptibility are unspecified.')
d.page('Dimensions & form','Nominal values from the existing source. No manufacturing tolerances are released.')
d.svg('module',275);d.svg('band',275)
d.para('The 11.5 mm housing excludes the 2.2 mm modeled button protrusion. The source gives 84.7 mm overall assembly height including the button; the original DBA-001 sheet shows 88.5 mm. The dimension discrepancy remains an engineering review item.',9,13)
d.page('Internal layout','Module section and component clearances.')
d.svg('section',315)
d.para('Packaging interfaces',15,20,True)
d.para('The source places the charging coil at 11.0-11.8 mm above the housing base; the nominal housing ends at 11.5 mm. The battery occupies 6.8-10.8 mm, extending into the nominal cap region. The switch/button stack also needs reconciliation. Wire routing, PCB keep-outs, ferrite, adhesives and battery allowance are not resolved.')
d.para('Housing & charging',15,20,True)
d.para('The module remains removable from the silicone band; that does not make the sealed cap user-openable. The button stays on top. Inductive charging through the cap avoids a band charging connector, with a dock, alignment and thermal design as trade-offs. The roughly two-hour charging time is a target. Sealing performance is not established by the charging choice.')
req=json.loads((P/'requirements.json').read_text())
for j in [0,5,10,15]:
 group=req[j:(j+5 if j<15 else len(req))];d.page('Engineering requirements & open questions',f'Register {j+1}-{j+len(group)} of {len(req)}. Design constraints, targets and pending engineering decisions.')
 for area,status,intent,owner,question in group:
  d.para(area+' | '+status,12,15,True,blue)
  d.para(html.escape(intent),9,12.5)
  d.para('<b>Unresolved:</b> '+html.escape(question)+'<br/><b>Discipline:</b> '+html.escape(owner),8.8,12.2)
d.page('Pricing & commercial assumptions','Proposed paired kit, cost assumptions and development status.')
d.para('Proposed offer',15,20,True)
d.para('A paired kit and shared charging dock, with a Rev A retail target of <b>$179-199 per pair</b>. Recreational buddy pairs are the intended users; instructors and dive shops are candidate channels. No customer interviews, orders, purchase commitments or market sizing are supplied.')
d.para('Cost basis',15,20,True)
d.para('Rev A estimates approximately <b>$43 per band / $86 per pair</b> at a volume of 5,000 pairs, with <b>±30% uncertainty</b>. This is a desk estimate, not a supplier quote. The dock is allocated across the pair. Tooling, non-recurring engineering, freight and duty are excluded. Returns, warranty, support and channel terms remain open; retail minus this estimate is not established profit.')
d.para('Product positioning',15,20,True)
d.para('The intended combination is a simple slip-on form, a paired tactile call and distance-coded cadence, without a screen or exposed charging connector on the band. Its usefulness over simpler attention tools, and whether divers want another wrist device, remain hypotheses.')
d.para('Development status',15,20,True)
d.para('Concept definition, proposed user interaction and an eleven-part parametric layout are available. Acoustic performance, customer demand, manufacturability, certification and intellectual-property clearance remain unestablished.')
d.para('Engineering scope',15,20,True)
d.para('The specification covers underwater acoustics, electronic control and power, firmware states, sealing, module retention and user interaction. Component envelopes and nominal dimensions require engineering development before manufacturing release.')
d.page('Design files','Concept specification, drawings and parametric source.')
for a,b in [('DBA_Interactive.html','Self-contained presentation content and original embedded mesh. Includes the narrative, interactive demo, projected dimensions, part callouts, drawing views and the requirements register. Three.js is loaded from its existing CDN.'),('DBA_Design_Package_RevB.pdf','Product concept, user interaction, technical specification and engineering review notes.'),('DBA_Annotated_Views_RevB.pdf','Three annotated concept views. Dimensions are nominal, not a manufacturing release.'),('cad/ and renders/','Unchanged original STEP, STL, DXF and render assets. The original drawing sheet is retained as a legacy reference; its discrepancies are recorded here.'),('dba_cad.py, render.py, drawing_sheet.py','Original source scripts, unchanged. Their original output path points to /home/claude/out; adapt the output location before any future authorized regeneration. No geometry has been regenerated in this revision.'),('presentation/','Editable presentation source, requirements register and generated annotation SVGs. The original int16 mesh payload is retained. Rebuild the presentation from these files.'),('legacy/DBA_Design_Package_RevA.pdf','Original reference preserved for traceability. Its ratings, performance wording, commercial claims and blanket tolerances are not established by the package.')]:d.para('<b>'+a+'</b><br/>'+b,9.3,13)
d.para('Future geometry edits must begin in dba_cad.py, then regenerate CAD, renders, the drawing sheet and the HTML mesh. This revision changes presentation and annotations only.',10,15,True)
d.save()
v=Doc('DBA_Annotated_Views_RevB.pdf')
for name,title,note in [('module','Module / top view','38 x 28 mm nominal housing. The 13 mm button opening is distinct from the 12.4 mm modeled stem and 16 mm flange. Housing height is 11.5 mm; button protrusion is a further 2.2 mm.'),('band','Band / front view','62 mm relaxed opening, 70 mm nominal band outside diameter, 24 mm axial band width and 4 mm radial wall. 84.7 mm overall source height includes the button. Wrist coverage and stretched fit are not demonstrated.'),('section','Module / schematic section','The section exposes unresolved cap, battery and coil clearances. It is an explanatory section, not a released manufacturing drawing. No tolerances, material approval or pressure rating are assigned.')]:
 v.page(title,'DBA annotated concept views / Revision B');v.svg(name,470);v.para(note);v.para('Source: original dba_cad.py and unchanged embedded geometry. Existing DBA-001 discrepancy: 88.5 mm overall versus 84.7 mm from the source. Drawings are not to scale and are not a fit or structural verification.',9,13)
v.save()
