from pathlib import Path
P=Path(__file__).resolve().parent
HEAD='<svg xmlns="http://www.w3.org/2000/svg" width="760" height="520" viewBox="0 0 760 520"><rect width="760" height="520" fill="white"/><defs><marker id="a" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 10 5 0 10Z" fill="#246591"/></marker></defs><g font-family="Arial,sans-serif" fill="#172d40" font-size="16">'
def text(x,y,t,size=16,col='#172d40'):return f'<text x="{x}" y="{y}" font-size="{size}" fill="{col}">{t}</text>'
def line(x,y,a,b,col='#172d40',dash=''):return f'<path d="M{x},{y}L{a},{b}" fill="none" stroke="{col}" stroke-width="1.5" stroke-dasharray="{dash}"/>'
def dim(x1,y1,x2,y2,label,off=28):
 import math
 d=math.hypot(x2-x1,y2-y1);nx=-(y2-y1)/d*off;ny=(x2-x1)/d*off
 ux=(x2-x1)/d;uy=(y2-y1)/d
 def arrow(x,y,v):
  a=(x+ux*8*v-uy*3,y+uy*8*v+ux*3);b=(x+ux*8*v+uy*3,y+uy*8*v-ux*3)
  return f'<polygon points="{x},{y} {a[0]},{a[1]} {b[0]},{b[1]}" fill="#246591"/>'
 arrows=arrow(x1+nx,y1+ny,1)+arrow(x2+nx,y2+ny,-1)
 return arrows+line(x1,y1,x1+nx,y1+ny,'#246591')+line(x2,y2,x2+nx,y2+ny,'#246591')+f'<path d="M{x1+nx},{y1+ny}L{x2+nx},{y2+ny}" stroke="#246591" />'+text((x1+x2)/2+nx+8,(y1+y2)/2+ny-8,label,16,'#246591')
def rect(x,y,w,h,fill='none',r=0):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" stroke="#172d40" stroke-width="2" fill="{fill}"/>'
def save(n,s): (P/(n+'.svg')).write_text(HEAD+s+text(28,488,'DBA / REV B  |  NOMINAL mm  |  CONCEPT ONLY - NOT TO SCALE',12)+ '</g></svg>')
s=text(28,38,'MODULE / TOP VIEW',22)+text(28,65,'Housing envelope excludes button protrusion.',14)
s+=rect(160,135,380,280,'#f3f6f8',60)+f'<circle cx="430" cy="275" r="65" fill="#f3d5d0" stroke="#172d40" stroke-width="2"/>'
s+=f'<circle cx="270" cy="185" r="10" fill="none" stroke="#172d40"/>'+line(140,275,560,275,'#8496a3','7 5')
s+=dim(160,135,540,135,'38.0',-30)+dim(540,135,540,415,'28.0',-50)+dim(365,275,495,275,'13.0 opening',0)
s+=line(270,185,80,180)+text(28,163,'2.0 LED opening',14)+text(170,446,'R6 nominal corners; button stem modeled at 12.4 diameter.',14)
save('module',s)
s=text(28,38,'BAND / FRONT VIEW',22)+text(28,65,'Existing source geometry, with the module assembled.',14)
s+='<circle cx="330" cy="295" r="140" fill="#edf1f5" stroke="#172d40" stroke-width="2"/><circle cx="330" cy="295" r="124" fill="white" stroke="#172d40" stroke-width="2"/>'
s+=rect(244,105,172,64,'#cdd6de',12)+rect(254,105,152,46,'none',8)+rect(336,96.2,49.6,8.8,'#eac1b8',3)
s+=line(170,295,510,295,'#8496a3','7 5')+dim(206,295,454,295,'62.0 wrist opening',0)+dim(190,435,470,435,'70.0 outside diameter',20)+dim(470,435,470,96.2,'84.7 overall',55)
s+=line(206,345,60,355)+text(28,376,'4.0 radial wall',15)+text(28,86,'24.0 band width along wrist axis; 33.0 cradle width.',14)
save('band',s)
s=text(28,38,'MODULE / SCHEMATIC SECTION',22)+text(28,65,'Internal packaging is unresolved. This view does not certify fit.',14)
# module section x scale 12, z scale 18; origin 110,390; housing top 183
s+=rect(110,183,456,207,'#f3f6f8',12)+rect(129.2,211.8,417.6,149.4,'white',5)
s+=line(110,242.4,566,242.4)+text(590,247,'8.2 split',14)
# internal nominal source heights relative base; PCB 5.5-6.5, batt6.8-10.8, coil11-11.8 cap max11.5
s+=rect(146,273,384,18,'#bed8cc')+text(30,285,'PCB',14)+line(72,280,146,280)
s+=rect(230,195.6,288,72,'#c6d5ec')+text(30,217,'Battery',14)+line(89,212,230,212)
s+=rect(254,177.6,240,14.4,'#e9c6a6')+text(375,136,'Coil crosses nominal cap top',15,'#a13327')+line(388,144,388,178,'#a13327')
s+=rect(446,307.2,120,54,'#d3d9de')+text(460,342,'Motor',12)+rect(152,348.6,180,21.6,'#f0dda6')+text(164,366,'Transducer',12)
s+=rect(332,143.4,148.8,39.6,'#e8b7ac',8)+text(470,121,'2.2 button protrusion',14)+line(484,125,474,145)
s+=dim(110,390,110,183,'11.5 housing',45)+dim(110,390,566,390,'38.0',32)
s+=text(28,456,'Cap/battery overlap, coil clearance and switch/button stack require reconciliation.',13)
save('section',s)
print('Three concept annotation SVGs created from existing source dimensions')
