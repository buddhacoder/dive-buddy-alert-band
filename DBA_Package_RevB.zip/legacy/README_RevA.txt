DIVE BUDDY ALERT BAND (DBA) — Concept package Rev A — 2026-09-03

DBA_Design_Package_RevA.pdf   11-page engineering/pitch document (send to builders)
DBA_Interactive.html          Single-file interactive site: 3D explode viewer + buddy-finder simulator
                              with phone haptics. Open in any browser; text/email/host it as-is.
cad/                          STEP (assembly + exploded + 11 parts), STL per part, DXF sections
drawings/                     DBA-001 dimensioned sheet (PDF/PNG), vector isometric + ortho SVGs
renders/                      Shaded PNGs used in the PDF
dba_cad.py                    Parametric source (Python + CadQuery). Edit a parameter, rerun, all CAD regenerates.
render.py / drawing_sheet.py  Regenerate renders and the drawing sheet.
deploy_pages.sh               Publish DBA_Interactive.html to GitHub Pages under Buddhacoder (needs gh CLI).
