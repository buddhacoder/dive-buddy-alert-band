import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyBboxPatch, Wedge
import numpy as np
plt.rcParams["font.family"]="DejaVu Sans"
INK="#1c2430"; DIM="#0f5ea8"; HID="#8a93a1"

fig = plt.figure(figsize=(16.5, 11), dpi=200); fig.patch.set_facecolor("white")
ax = fig.add_axes([0,0,1,1]); ax.set_xlim(0,300); ax.set_ylim(0,200); ax.set_aspect("equal"); ax.axis("off")
# frame + title block
ax.add_patch(Rectangle((3,3),294,194, fill=False, ec=INK, lw=1.4))
ax.add_patch(Rectangle((197,3),100,26, fill=False, ec=INK, lw=1.2))
for y in (11,20): ax.plot([197,297],[y,y], color=INK, lw=0.7)
ax.plot([247,247],[3,20], color=INK, lw=0.7)
ax.text(200,24.5,"DIVE BUDDY ALERT BAND (DBA)", fontsize=11, weight="bold", color=INK, va="center")
ax.text(295,24.5,"DWG  DBA-001   REV A", fontsize=8.5, color=INK, va="center", ha="right")
ax.text(200,15.5,"CONCEPT LAYOUT — MODULE & BAND", fontsize=8, color=INK, va="center")
ax.text(250,15.5,"SCALE  1:1 (A3)   UNITS  mm", fontsize=8, color=INK, va="center")
ax.text(200,7,"MATL: band LSR Sh-A 35 · shells PA12/PC · button LSR Sh-A 50", fontsize=6.0, color=INK, va="center")
ax.text(295,7,"TOL ±0.2 · 2026-09-03", ha="right", fontsize=7.2, color=INK, va="center")

def dim(x1,y1,x2,y2,text,off=6,orient="h",fs=7.5):
    if orient=="h":
        y=y1+off; ax.plot([x1,x1],[y1,y+1.5*np.sign(off)],color=DIM,lw=0.6); ax.plot([x2,x2],[y2,y+1.5*np.sign(off)],color=DIM,lw=0.6)
        ax.annotate("",(x1,y),(x2,y),arrowprops=dict(arrowstyle="<|-|>",color=DIM,lw=0.7,mutation_scale=7))
        ax.text((x1+x2)/2,y+1.2,text,ha="center",va="bottom",fontsize=fs,color=DIM)
    else:
        x=x1+off; ax.plot([x1,x+1.5*np.sign(off)],[y1,y1],color=DIM,lw=0.6); ax.plot([x2,x+1.5*np.sign(off)],[y2,y2],color=DIM,lw=0.6)
        ax.annotate("",(x,y1),(x,y2),arrowprops=dict(arrowstyle="<|-|>",color=DIM,lw=0.7,mutation_scale=7))
        ax.text(x+1.2,(y1+y2)/2,text,ha="left",va="center",fontsize=fs,color=DIM,rotation=90)

def rrect(x,y,w,h,r,**kw):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f"round,pad=0,rounding_size={r}",**kw))

# ---------- VIEW A: module plan (top)  centred at (32,80)
cx,cy=55,148; L,W,R=38,28,6
ax.text(cx-30,cy+26,"A   MODULE — PLAN VIEW", fontsize=8.5, weight="bold", color=INK)
rrect(cx-L/2,cy-W/2,L,W,R,fill=False,ec=INK,lw=1.1)
ax.add_patch(Circle((cx+8,cy),6.5,fill=False,ec=INK,lw=1.0))
ax.add_patch(Circle((cx+8,cy),8.0,fill=False,ec=HID,lw=0.6,ls=(0,(2,1.5))))  # flange under cap (hidden)
ax.add_patch(Circle((cx-8,cy+9),1.0,fill=False,ec=INK,lw=0.8))
ax.add_patch(Circle((cx-8,cy),7.5,fill=False,ec=HID,lw=0.6,ls=(0,(2,1.5))))   # piezo (hidden)
ax.plot([cx-L/2+2,cx+L/2-2],[cy,cy],color=HID,lw=0.4,ls=(0,(6,2,1,2)))
ax.plot([cx,cx],[cy-W/2-2,cy+W/2+2],color=HID,lw=0.4,ls=(0,(6,2,1,2)))
dim(cx-L/2,cy+W/2,cx+L/2,cy+W/2,"38.0",off=4)
dim(cx+L/2,cy-W/2,cx+L/2,cy+W/2,"28.0",off=4,orient="v")
dim(cx-L/2,cy-W/2,cx+8,cy-W/2,"27.0",off=-4)
ax.annotate("Ø13.0 BUTTON",(cx+8+4.6,cy+4.6),(cx+26,cy+18),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))
ax.annotate("Ø2.0 LED WINDOW",(cx-8+0.7,cy+9.7),(cx-46,cy+18),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))
ax.annotate("Ø15 PIEZO (HIDDEN)",(cx-8-5.3,cy-5.3),(cx-48,cy-20),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))
ax.text(cx+2,cy-W/2-12,"R6.0 TYP. CORNERS", fontsize=7, color=DIM)

# ---------- VIEW B: module section (front) centred at (80,80)
bx,by=150,140; H=11.5; SPLIT=8.2; T=1.6
ax.text(bx-30,by+34,"B   MODULE — SECTION B-B", fontsize=8.5, weight="bold", color=INK)
# outer shell profile
rrect(bx-L/2,by,L,H,2.0,fill=False,ec=INK,lw=1.1)
rrect(bx-L/2+T,by+T,L-2*T,H-2*T,1.0,fill=False,ec=INK,lw=0.7)
ax.plot([bx-L/2,bx+L/2],[by+SPLIT,by+SPLIT],color=INK,lw=0.8)          # split line
ax.add_patch(Circle((bx-L/2+T+1.0,by+SPLIT),0.5,fill=True,fc=INK)); ax.add_patch(Circle((bx+L/2-T-1.0,by+SPLIT),0.5,fill=True,fc=INK))
# button dome + flange
ax.add_patch(Wedge((bx+8,by+H),6.0,0,180,width=None,fill=False,ec=INK,lw=1.0))
ax.plot([bx+8-8,bx+8+8],[by+H-T-1.0,by+H-T-1.0],color=INK,lw=0.7); ax.plot([bx+8-8,bx+8+8],[by+H-T,by+H-T],color=INK,lw=0.7)
# internals (schematic)
ax.add_patch(Rectangle((bx-16,by+T+3.0),32,1.0,fill=True,fc="#cfe8d8",ec=INK,lw=0.5))      # pcb
ax.add_patch(Rectangle((bx-9,by+T+4.3),24,4.0,fill=True,fc="#d6dcf2",ec=INK,lw=0.5))       # battery
ax.add_patch(Rectangle((bx-9,by+T+8.6),20,0.8,fill=True,fc="#f0d9c4",ec=INK,lw=0.5))       # coil
ax.add_patch(Rectangle((bx-15.5,by+T-0.5),15,1.2,fill=True,fc="#f3e2a8",ec=INK,lw=0.5))    # piezo
ax.add_patch(Rectangle((bx+5,by+T),10,3.0,fill=True,fc="#dddfe3",ec=INK,lw=0.5))           # motor
ax.plot([bx-15.5,bx-0.5],[by+0.6,by+0.6],color=INK,lw=1.4)                                  # 0.6 membrane
dim(bx-L/2,by,bx-L/2,by+H,"11.5",off=-5,orient="v")
dim(bx+L/2,by,bx+L/2,by+SPLIT,"8.2",off=5,orient="v")
dim(bx-L/2,by+H,bx-L/2+T,by+H,"1.6",off=4,fs=6.5)
ax.annotate("0.6 ACOUSTIC MEMBRANE",(bx-8,by+0.6),(bx-40,by-10),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))
ax.annotate("O-RING Ø1.0 CS, NBR 70",(bx+L/2-T-1.0,by+SPLIT),(bx+28,by+SPLIT-8),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))
ax.annotate("LSR DOME, 2.2 TRAVEL",(bx+8,by+H+6),(bx+26,by+H+14),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))
ax.annotate("Li-Po 150 mAh",(bx+3,by+T+6.3),(bx-46,by+T+16),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))
ax.annotate("Qi RX COIL",(bx+1,by+T+9.0),(bx-46,by+T+24),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))

# ---------- VIEW C: band front elevation centred at (137,66)
ccx,ccy=240,112; ID=62; Tb=4
ax.text(ccx-40,ccy+70,"C   BAND — FRONT ELEVATION", fontsize=8.5, weight="bold", color=INK)
ax.add_patch(Circle((ccx,ccy),ID/2+Tb,fill=False,ec=INK,lw=1.1))
ax.add_patch(Circle((ccx,ccy),ID/2,fill=False,ec=INK,lw=1.1))
# cradle silhouette on top
top=ccy+ID/2+Tb
rrect(ccx-21.5,top-3,43,3+8.5+4,4,fill=False,ec=INK,lw=1.0)
rrect(ccx-19,top+1,38,11.5,2,fill=False,ec=HID,lw=0.6,ls=(0,(2,1.5)))
ax.add_patch(Wedge((ccx+8,top+12.5),6.0,0,180,fill=False,ec=INK,lw=0.9))
ax.plot([ccx,ccx],[ccy-ID/2-Tb-3,top+24],color=HID,lw=0.4,ls=(0,(6,2,1,2)))
ax.plot([ccx-ID/2-Tb-3,ccx+ID/2+Tb+3],[ccy,ccy],color=HID,lw=0.4,ls=(0,(6,2,1,2)))
dim(ccx-ID/2,ccy,ccx+ID/2,ccy,"Ø62.0 RELAXED (stretch to Ø95 max)",off=-1.5)
dim(ccx-ID/2-Tb,ccy-ID/2-Tb,ccx+ID/2+Tb,ccy-ID/2-Tb,"Ø70.0",off=-5)
dim(ccx+ID/2+Tb,ccy-ID/2-Tb,ccx+ID/2+Tb,top+12.5+6,"88.5 OVERALL",off=8,orient="v")
dim(ccx-21.5,top+12.5,ccx+21.5,top+12.5,"43.0",off=8)
ax.annotate("4.0 WALL",(ccx-ID/2-2,ccy-12),(ccx-ID/2-28,ccy-26),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))
ax.annotate("Ø12 ACOUSTIC WINDOW (under piezo)",(ccx-8,top-2),(ccx-62,top-22),fontsize=7,color=DIM,arrowprops=dict(arrowstyle="-",color=DIM,lw=0.6))

# ---------- VIEW D: band section (side) at (137,22)... place left-bottom instead
dx,dy=110,58; BW=24
ax.text(dx-40,dy+26,"D   BAND — SECTION D-D (through cradle)", fontsize=8.5, weight="bold", color=INK)
ax.add_patch(Rectangle((dx-BW/2,dy-2),BW,Tb,fill=True,fc="#e9eaee",ec=INK,lw=1.0,hatch="///"))
rrect(dx-16.5,dy+2,33,12.5,3,fill=True,fc="#e9eaee",ec=INK,lw=1.0,hatch="///")
rrect(dx-14,dy+3,28,11.5,2,fill=True,fc="white",ec=INK,lw=0.8)          # pocket
ax.add_patch(Rectangle((dx-6,dy-2),12,5,fill=True,fc="white",ec=INK,lw=0.7))   # acoustic window
dim(dx-BW/2,dy-2,dx+BW/2,dy-2,"24.0 BAND WIDTH",off=-5)
dim(dx+BW/2,dy-2,dx+BW/2,dy+2,"4.0",off=4,orient="v",fs=6.5)
dim(dx-16.5,dy+14.5,dx+16.5,dy+14.5,"33.0",off=3)
dim(dx-16.5,dy+2,dx-16.5,dy+14.5,"12.5",off=-5,orient="v")
ax.text(dx-40,dy-14,"Cradle retains module by interference (0.2 mm) + undercut lip; module removable for service.", fontsize=7, color=INK)

# notes
notes=["NOTES",
"1. Module sealed to 6 bar (≈50 m); IP68. Cap bonded or ultrasonically welded to base; O-ring is secondary seal.",
"2. Piezo bonded to 0.6 mm membrane with rigid epoxy; membrane faces water through band window.",
"3. Button: LSR dome over tactile switch, 2.2 mm travel, 3–4 N actuation (glove-operable, resists inadvertent press).",
"4. No external contacts: charging by inductive coil through cap. Charge dock cradle sold with pair.",
"5. Band: one-piece LSR moulding, Sh-A 35, tear-resistant grade; slip-on, fits bare wrist to 7 mm suit cuff.",
"6. All geometry parametric — see dba_cad.py; STEP/STL/DXF in /cad."]
for i,n in enumerate(notes):
    ax.text(8,32-i*3.6,n,fontsize=7.4 if i else 8.2,weight="bold" if i==0 else "normal",color=INK)
fig.savefig("/home/claude/out/drawings/DBA-001_drawing_sheet.png", facecolor="white")
fig.savefig("/home/claude/out/drawings/DBA-001_drawing_sheet.pdf", facecolor="white")
print("sheet done")
