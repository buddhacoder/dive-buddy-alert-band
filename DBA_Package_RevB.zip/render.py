import numpy as np, glob, os, re
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import proj3d
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from stl import mesh as stlmesh

CAD = "/home/claude/out/cad"; OUT = "/home/claude/out/renders"; os.makedirs(OUT, exist_ok=True)
plt.rcParams["font.family"] = "DejaVu Sans"

PARTS = [  # (file stem, label, colour, explode dz)
 ("01_band_silicone",   "Silicone slip-on band + cradle",          "#3a3f47", -14),
 ("02_base_shell",      "Base shell (PA12 / PC) with acoustic port", "#5c6370",   0),
 ("03_piezo_transducer","Piezo ultrasonic transducer, 60–70 kHz",   "#d9a520",   6),
 ("04_vibration_motor", "Coin LRA haptic motor",                   "#8f949c",   6),
 ("05_pcb",             "Main PCB (MCU + acoustic front-end)",     "#1f7a4d",  12),
 ("06_tact_switch",     "Tactile switch (sealed dome above)",      "#c9ccd1",  16),
 ("07_battery_lipo",    "3.7 V 150 mAh Li-Po cell",                "#3f5fb3",  20),
 ("08_qi_receiver_coil","Inductive (Qi) charging coil",            "#b8732f",  27),
 ("09_o_ring",          "O-ring seal",                             "#101214",  33),
 ("10_top_cap",         "Top cap (ultrasonic-welded / bonded)",    "#7d8390",  40),
 ("11_button_dome",     "Overmoulded silicone push button",        "#d94c3d",  48),
]

def load(stem):
    m = stlmesh.Mesh.from_file(f"{CAD}/{stem}.stl")
    return m.vectors.copy()

LIGHT = np.array([0.4, -0.6, 0.7]); LIGHT /= np.linalg.norm(LIGHT)
def shade(tris, base):
    n = np.cross(tris[:,1]-tris[:,0], tris[:,2]-tris[:,0])
    n /= (np.linalg.norm(n, axis=1, keepdims=True) + 1e-9)
    lam = np.clip(n @ LIGHT, 0, 1)
    rgb = np.array(matplotlib.colors.to_rgb(base))
    cols = 0.42*rgb + 0.72*rgb*lam[:,None] + 0.16*lam[:,None]**10  # ambient + diffuse + spec
    return np.clip(cols, 0, 1)

def cull(t, elev, azim):
    e, a = np.radians(elev), np.radians(azim)
    v = np.array([np.cos(e)*np.cos(a), np.cos(e)*np.sin(a), np.sin(e)])
    n = np.cross(t[:,1]-t[:,0], t[:,2]-t[:,0])
    return t[(n @ v) > 0]

def scene(ax, explode, elev, azim, subset=None, zoom=1.15):
    allpts, tris, cols = [], [], []
    for stem, label, col, dz in PARTS:
        if subset and stem not in subset: continue
        t = load(stem)
        if explode: t = t + np.array([0,0,dz*1.7])
        allpts.append(t.reshape(-1,3)); t = cull(t, elev, azim)
        tris.append(t); cols.append(shade(t, col))
    T = np.vstack(tris); C = np.vstack(cols)
    pc = Poly3DCollection(T, facecolors=C, edgecolors=C, linewidths=0.35); pc.set_zsort("average")
    ax.add_collection3d(pc)
    P = np.vstack(allpts); lo, hi = P.min(0), P.max(0); ext = hi-lo; pad = 0.04*ext.max()
    ax.set_xlim(lo[0]-pad, hi[0]+pad); ax.set_ylim(lo[1]-pad, hi[1]+pad); ax.set_zlim(lo[2]-pad, hi[2]+pad)
    ax.set_box_aspect(tuple(ext+2*pad), zoom=zoom); ax.view_init(elev=elev, azim=azim); ax.set_axis_off()
    c, r = (lo+hi)/2, ext.max()/2
    ax.set_proj_type("ortho")
    return c, r

def fig3d(size=(8,8), bg="#0b1520"):
    fig = plt.figure(figsize=size, dpi=220); fig.patch.set_facecolor(bg)
    ax = fig.add_subplot(111, projection="3d"); ax.set_facecolor(bg)
    return fig, ax

SHELL={"01_band_silicone","02_base_shell","10_top_cap","11_button_dome"}
# 1. hero render (assembled, dark)
fig, ax = fig3d((8,7))
scene(ax, False, 26, -48, subset=SHELL, zoom=1.0)
fig.subplots_adjust(0,0,1,1); fig.savefig(f"{OUT}/hero_assembled.png", facecolor=fig.get_facecolor()); plt.close(fig)

# 2. hero from wrist-side low angle
fig, ax = fig3d((8,7))
scene(ax, False, 14, 30, subset=SHELL, zoom=1.0)
fig.subplots_adjust(0,0,1,1); fig.savefig(f"{OUT}/hero_low.png", facecolor=fig.get_facecolor()); plt.close(fig)

# 3. module only, top view (button + LED)
fig, ax = fig3d((7,7), bg="#ffffff")
scene(ax, False, 62, -40, subset=SHELL-{"01_band_silicone"}, zoom=1.0)
fig.subplots_adjust(0,0,1,1); fig.savefig(f"{OUT}/module_top.png", facecolor="white"); plt.close(fig)

# 4. annotated exploded view (light background, callouts)
fig = plt.figure(figsize=(9,12), dpi=220); fig.patch.set_facecolor("#f6f7f9")
ax = fig.add_subplot(111, projection="3d"); ax.set_facecolor("#f6f7f9")
c, r = scene(ax, True, 18, -55, zoom=1.28)
fig.subplots_adjust(-0.04,0.0,0.62,0.93)
# compute label anchor: centroid of each exploded part, projected to 2D
fig.canvas.draw()
anchors=[]
for i,(stem,label,col,dz) in enumerate(PARTS, start=1):
    t = load(stem) + np.array([0,0,dz*1.7]); cen = t.reshape(-1,3).mean(0)
    x2,y2,_ = proj3d.proj_transform(*cen, ax.get_proj())
    fx, fy = fig.transFigure.inverted().transform(ax.transData.transform((x2,y2)))
    anchors.append((i,label,col,fx,fy))
order = sorted(anchors, key=lambda a: -a[4])
for k,(i,label,col,fx,fy) in enumerate(order):
    ty = 0.88 - k*0.072
    fig.add_artist(matplotlib.lines.Line2D([fx, 0.56, 0.665], [fy, ty, ty], transform=fig.transFigure, color=col, lw=1.2, alpha=0.95, solid_capstyle="round"))
    fig.add_artist(matplotlib.patches.Circle((fx,fy), 0.006, transform=fig.transFigure, fc=col, ec="white", lw=0.9))
    fig.text(0.675, ty, f"{i:02d}", ha="left", va="center", fontsize=10, weight="bold", color=col)
    fig.text(0.712, ty, label, ha="left", va="center", fontsize=8.6, wrap=True, color="#1c1f24")
fig.text(0.03, 0.965, "DIVE BUDDY ALERT BAND — EXPLODED ASSEMBLY", fontsize=13, weight="bold", color="#1c1f24")
fig.text(0.03, 0.945, "Rev A concept · all parts parametric (see dba_cad.py) · dimensions in mm", fontsize=8.5, color="#5c6370")
fig.savefig(f"{OUT}/exploded_annotated.png", facecolor=fig.get_facecolor()); plt.close(fig)

# 5. orthographic drawing sheet (front / side / top) with overall dimensions
def ortho(ax, elev, azim, title):
    c, r = scene(ax, False, elev, azim, subset=SHELL, zoom=1.0)
    ax.set_title(title, fontsize=9, color="#1c1f24", pad=2)
fig = plt.figure(figsize=(11, 4.2), dpi=220); fig.patch.set_facecolor("white")
for k,(elev,azim,t) in enumerate([(0,-90,"FRONT  (wrist axis into page)"),(0,0,"SIDE"),(90,-90,"TOP")]):
    ax = fig.add_subplot(1,3,k+1, projection="3d"); ax.set_facecolor("white"); ortho(ax, elev, azim, t)
fig.subplots_adjust(0.01,0.02,0.99,0.92, wspace=0.02)
fig.savefig(f"{OUT}/ortho_sheet.png", facecolor="white"); plt.close(fig)
print("renders done")
