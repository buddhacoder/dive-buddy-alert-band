"""
Dive Buddy Alert (DBA) Band — parametric CAD model
Units: millimetres.  Author: generated for Rafy / Dr. R. Duclas Jr.
Edit the PARAMETERS block; everything downstream regenerates.
"""
import math, os
import cadquery as cq
from cadquery import exporters

OUT = "/home/claude/out"
os.makedirs(f"{OUT}/cad", exist_ok=True)
os.makedirs(f"{OUT}/drawings", exist_ok=True)

# ------------------------------------------------------------------ PARAMETERS
BAND_ID      = 62.0    # relaxed inner diameter (stretches to ~95 mm over a 7 mm suit)
BAND_W       = 24.0    # band width (axial)
BAND_T       = 4.0     # band wall thickness (radial)
CRADLE_H     = 7.0     # how far the silicone cradle stands proud of the band

MOD_L, MOD_W, MOD_H = 38.0, 28.0, 11.5     # sealed module envelope
MOD_R        = 6.0     # corner radius
SHELL_T      = 1.6     # housing wall
SPLIT_Z      = 3.2     # top-cap / base split height from module bottom
ORING_CS     = 1.0     # O-ring cross-section

BTN_D        = 13.0    # push-button dome diameter (glove-friendly)
BTN_H        = 2.2
PCB_L, PCB_W, PCB_T = 32.0, 22.0, 1.0
BAT_L, BAT_W, BAT_T = 24.0, 18.0, 4.0     # 3.7 V 150 mAh LiPo
MOTOR_D, MOTOR_T    = 10.0, 3.0           # coin LRA/ERM
PIEZO_D, PIEZO_T    = 15.0, 1.2           # 70 kHz piezo disc (transducer)
COIL_OD, COIL_ID, COIL_T = 20.0, 8.0, 0.8 # Qi receiver coil
LED_D        = 2.0     # light-pipe window

# ------------------------------------------------------------------ helpers
def rbox(l, w, h, r):
    return cq.Workplane("XY").box(l, w, h).edges("|Z").fillet(r)

# ------------------------------------------------------------------ BAND
band = (cq.Workplane("XY")
        .circle(BAND_ID/2 + BAND_T).circle(BAND_ID/2)
        .extrude(BAND_W).translate((0, 0, -BAND_W/2))
        .rotate((0,0,0), (1,0,0), 90))            # axis along Y (wrist axis)

# cradle: silicone bezel on top of band that grips the module
cradle_outer = (rbox(MOD_L + 2*2.5, MOD_W + 2*2.5, MOD_H + CRADLE_H - 3, MOD_R + 2.5)
                .translate((0, 0, BAND_ID/2 + BAND_T - 3 + (MOD_H + CRADLE_H - 3)/2)))
# blend cradle into the band curvature
cradle_outer = cradle_outer.edges(">Z").fillet(2.5)
cradle_pocket = (rbox(MOD_L + 0.2, MOD_W + 0.2, MOD_H + 5, MOD_R)
                 .translate((0, 0, BAND_ID/2 + BAND_T + MOD_H/2 + 1.0)))
# acoustic window: through-hole under the piezo so sound couples to water
acoustic_window = (cq.Workplane("XY").circle(PIEZO_D/2 - 1.5).extrude(20)
                   .translate((-8, 0, BAND_ID/2 - 6)))
band = band.union(cradle_outer).cut(cradle_pocket).cut(acoustic_window)

# ------------------------------------------------------------------ MODULE
Z0 = BAND_ID/2 + BAND_T + 1.0                     # module bottom sits here
def up(z): return Z0 + z

# base shell (bottom part), holds electronics
base_outer = rbox(MOD_L, MOD_W, SPLIT_Z + 5.0, MOD_R).translate((0,0, up((SPLIT_Z+5.0)/2)))
base_inner = rbox(MOD_L-2*SHELL_T, MOD_W-2*SHELL_T, SPLIT_Z + 5.0, MOD_R-SHELL_T) \
                .translate((0,0, up(SHELL_T + (SPLIT_Z+5.0)/2)))
base = base_outer.cut(base_inner)
# acoustic port: thin 0.6 mm membrane over piezo (2 mm recess for coupling gel)
base = base.cut(cq.Workplane("XY").circle(PIEZO_D/2).extrude(SHELL_T-0.6).translate((-8,0,up(0))))
# O-ring groove on base rim
groove = (cq.Workplane("XY")
          .rect(MOD_L-2*SHELL_T-ORING_CS, MOD_W-2*SHELL_T-ORING_CS)
          .rect(MOD_L-2*SHELL_T-3*ORING_CS, MOD_W-2*SHELL_T-3*ORING_CS)
          .extrude(ORING_CS*0.7).translate((0,0, up(SPLIT_Z+5.0-ORING_CS*0.7))))
base = base.cut(groove)

# top cap
cap_h = MOD_H - (SPLIT_Z + 5.0)
cap = rbox(MOD_L, MOD_W, cap_h, MOD_R).translate((0,0, up(SPLIT_Z+5.0+cap_h/2)))
cap = cap.edges(">Z").fillet(1.8)
cap_inner = rbox(MOD_L-2*SHELL_T, MOD_W-2*SHELL_T, cap_h-SHELL_T, MOD_R-SHELL_T) \
                .translate((0,0, up(SPLIT_Z+5.0+(cap_h-SHELL_T)/2)))
cap = cap.cut(cap_inner)
# button bore + LED window
cap = cap.cut(cq.Workplane("XY").circle(BTN_D/2).extrude(MOD_H).translate((8,0,up(0))))
cap = cap.cut(cq.Workplane("XY").circle(LED_D/2).extrude(MOD_H).translate((-8,9,up(0))))

# silicone button dome (overmoulded, sealed)
button = (cq.Workplane("XY").circle(BTN_D/2 + 1.5).extrude(1.0).translate((8,0,up(MOD_H-SHELL_T-1.0)))
          .union(cq.Workplane("XY").circle(BTN_D/2 - 0.3).extrude(BTN_H + SHELL_T)
                 .translate((8,0,up(MOD_H-SHELL_T)))).faces(">Z").fillet(1.5))

# internals
pcb   = rbox(PCB_L, PCB_W, PCB_T, 2).translate((0,0, up(SHELL_T + MOTOR_T + 0.6 + PCB_T/2 + 0.3)))
bat   = rbox(BAT_L, BAT_W, BAT_T, 1.5).translate((3,0, up(SHELL_T + MOTOR_T + 0.9 + PCB_T + BAT_T/2 + 0.3)))
motor = cq.Workplane("XY").circle(MOTOR_D/2).extrude(MOTOR_T).translate((10,0, up(SHELL_T+0.3)))
piezo = cq.Workplane("XY").circle(PIEZO_D/2).extrude(PIEZO_T).translate((-8,0, up(SHELL_T-0.6+0.1)))
coil  = (cq.Workplane("XY").circle(COIL_OD/2).circle(COIL_ID/2).extrude(COIL_T)
         .translate((3,0, up(SHELL_T + MOTOR_T + 0.9 + PCB_T + BAT_T + 0.5))))
oring = (cq.Workplane("XY")
         .rect(MOD_L-2*SHELL_T-ORING_CS, MOD_W-2*SHELL_T-ORING_CS)
         .rect(MOD_L-2*SHELL_T-3*ORING_CS, MOD_W-2*SHELL_T-3*ORING_CS)
         .extrude(ORING_CS).translate((0,0, up(SPLIT_Z+5.0-ORING_CS*0.7))))
tact  = cq.Workplane("XY").circle(3).extrude(1.8).translate((8,0, up(SHELL_T + MOTOR_T + 0.9 + PCB_T + 0.3)))

parts = {   # name: (solid, colour, exploded z-offset)
    "01_band_silicone":      (band,   (0.16,0.17,0.19), -14),
    "02_base_shell":         (base,   (0.35,0.38,0.42),   0),
    "03_piezo_transducer":   (piezo,  (0.85,0.70,0.20),   6),
    "04_vibration_motor":    (motor,  (0.55,0.55,0.58),   6),
    "05_pcb":                (pcb,    (0.10,0.45,0.30),  12),
    "06_tact_switch":        (tact,   (0.80,0.80,0.80),  16),
    "07_battery_lipo":       (bat,    (0.25,0.35,0.70),  20),
    "08_qi_receiver_coil":   (coil,   (0.72,0.45,0.20),  27),
    "09_o_ring":             (oring,  (0.10,0.10,0.10),  33),
    "10_top_cap":            (cap,    (0.45,0.48,0.52),  40),
    "11_button_dome":        (button, (0.90,0.30,0.25),  48),
}

# ------------------------------------------------------------------ EXPORT
asm = cq.Assembly(name="DBA_Band")
expl = cq.Assembly(name="DBA_Band_Exploded")
for name,(solid,col,dz) in parts.items():
    exporters.export(solid, f"{OUT}/cad/{name}.stl", tolerance=0.02, angularTolerance=0.1)
    exporters.export(solid, f"{OUT}/cad/{name}.step")
    asm.add(solid, name=name, color=cq.Color(*col))
    expl.add(solid.translate((0,0,dz)), name=name, color=cq.Color(*col))
asm.save(f"{OUT}/cad/DBA_Band_assembly.step")
expl.save(f"{OUT}/cad/DBA_Band_exploded.step")

# combined compound for SVG line-art
def compound(dz=False):
    return cq.Compound.makeCompound([ (s.translate((0,0,d)) if dz else s).val()
                                      for s,_,d in parts.values() ])
svgopt = dict(width=900, height=700, marginLeft=20, marginTop=20,
              showAxes=False, strokeWidth=0.6, strokeColor=(30,35,45),
              hiddenColor=(160,160,170), showHidden=False)
exporters.export(compound(False), f"{OUT}/drawings/iso_assembled.svg",
                 opt={**svgopt, "projectionDir": (1.2,-1.6,1.0)})
exporters.export(compound(True),  f"{OUT}/drawings/iso_exploded.svg",
                 opt={**svgopt, "height":1100, "projectionDir": (1.2,-1.6,0.9)})
for view,dirn in {"front":(0,-1,0), "top":(0,0,1), "side":(1,0,0)}.items():
    exporters.export(compound(False), f"{OUT}/drawings/ortho_{view}.svg",
                     opt={**svgopt, "projectionDir": dirn, "showHidden": True})

# DXF: 2-D sections of the module for AutoCAD
sec_xz = cq.Workplane("XZ").add(cq.Compound.makeCompound([base.val(),cap.val(),pcb.val(),bat.val(),piezo.val(),motor.val(),coil.val()]))
try:
    section = cq.Workplane("XY").add(cq.Compound.makeCompound(
        [s.val() for s in (base,cap,pcb,bat,piezo,motor,coil,button)])).section(up(MOD_H/2))
    exporters.exportDXF(section, f"{OUT}/cad/module_plan_section.dxf")
except Exception as e:
    print("DXF plan section failed:", e)
try:
    top_outline = cq.Workplane("XY").add(cq.Compound.makeCompound([base.val(),cap.val()])).section(up(SPLIT_Z+5.0))
    exporters.exportDXF(top_outline, f"{OUT}/cad/module_split_line.dxf")
except Exception as e:
    print("DXF split failed:", e)

# bounding-box report for the spec table
bb = compound(False).BoundingBox()
print(f"Assembly bbox: {bb.xlen:.1f} x {bb.ylen:.1f} x {bb.zlen:.1f} mm")
mbb = cq.Compound.makeCompound([base.val(),cap.val(),button.val()]).BoundingBox()
print(f"Module bbox:   {mbb.xlen:.1f} x {mbb.ylen:.1f} x {mbb.zlen:.1f} mm")
print("done")
