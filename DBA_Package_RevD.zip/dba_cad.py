"""Dive Buddy Alert Band — Rev D parametric concept layout, by Rafael.
Millimetres. Edit named parameters here; regenerate CAD before presentation assets.
Envelopes are unselected components. Solid consistency is not physical validation.
"""
from pathlib import Path
import itertools
import json
import cadquery as cq
from cadquery import exporters

# ----------------------------- PARAMETERS (mm unless stated)
BAND_ID, BAND_W, BAND_T = 62.0, 24.0, 4.0
MOD_L, MOD_W, MOD_H, MOD_R = 44.0, 32.0, 17.5, 6.0
SHELL_T, BASE_H, SPLIT_Z, Z0 = 2.0, 9.0, 9.0, 36.0
CRADLE_MARGIN, CRADLE_BOTTOM, CRADLE_TOP = 2.5, 32.0, 46.0
CRADLE_CLEARANCE, CRADLE_FLOOR_CLEARANCE = 0.2, 0.2
CRADLE_LIP_CLEARANCE, CRADLE_LIP_H = 0.1, 0.8
CRADLE_EDGE_R, CAP_EDGE_R = 1.0, 0.7
BTN_X, BTN_Y, BTN_D, BTN_STEM_D, BTN_H = 10.0, 0.0, 13.0, 12.4, 2.2
BTN_FLANGE_D, BTN_FLANGE_T, BTN_FLANGE_Z, BTN_EDGE_R = 16.0, 1.0, 14.5, 0.8
PLUNGER_D, PLUNGER_Z = 4.0, 9.1
PCB_L, PCB_W, PCB_T, PCB_X, PCB_Z, PCB_R = 32.0, 22.0, 1.0, 0.0, 6.0, 2.0
BAT_L, BAT_W, BAT_T, BAT_X, BAT_Z, BAT_R = 24.0, 18.0, 4.0, -7.0, 7.3, 1.5
MOTOR_D, MOTOR_T, MOTOR_X, MOTOR_Z = 10.0, 3.0, 10.0, 2.3
PIEZO_D, PIEZO_T, PIEZO_X, PIEZO_Z = 15.0, 1.2, -10.0, 0.7
MEMBRANE_T, PIEZO_CLEARANCE, ACOUSTIC_WINDOW_D = 0.6, 0.2, 12.0
ACOUSTIC_CUT_BOTTOM, ACOUSTIC_CUT_H = 25.0, 12.0
COIL_OD, COIL_ID, COIL_T, COIL_X, COIL_Z = 20.0, 8.0, 0.8, 10.0, 12.0
SWITCH_D, SWITCH_T, SWITCH_X, SWITCH_Z = 6.0, 1.8, 10.0, 7.3
DISPLAY_X, DISPLAY_Y, DISPLAY_L, DISPLAY_W, DISPLAY_T, DISPLAY_Z = -10.0, 0.0, 16.0, 18.0, 2.5, 13.5
WINDOW_L, WINDOW_W, WINDOW_T, WINDOW_Z, WINDOW_R = 18.0, 20.0, 1.2, 16.3, 0.9
ACTIVE_L, ACTIVE_W, DISPLAY_R = 14.0, 16.0, 0.5
WINDOW_CLEARANCE, DISPLAY_CLEARANCE = 0.2, 0.2
SEAL_W, SEAL_H, SEAL_RADIAL_CLEARANCE, SEAL_AXIAL_CLEARANCE = 0.8, 0.8, 0.2, 0.2
SEAL_CENTER_L, SEAL_CENTER_W, SEAL_CENTER_R = 42.0, 30.0, 5.0
STL_TOLERANCE, STL_ANGULAR_TOLERANCE = 0.025, 0.08
BOOLEAN_VOLUME_TOLERANCE = 0.00001

ROOT = Path(__file__).resolve().parent
CAD, DRAW, QA = ROOT/'cad', ROOT/'drawings', ROOT/'output'/'qa'
for directory in (CAD, DRAW, QA): directory.mkdir(parents=True, exist_ok=True)

def rbox(length, width, height, radius, x=0, y=0, bottom=0):
    return cq.Workplane('XY').box(length, width, height).edges('|Z').fillet(radius).translate((x,y,bottom+height/2))

def cylinder(diameter, height, x=0, y=0, bottom=0):
    return cq.Workplane('XY').circle(diameter/2).extrude(height).translate((x,y,bottom))

def rounded_ring(length, width, radius, radial_width, height, bottom):
    outer = rbox(length+radial_width, width+radial_width, height, radius+radial_width/2, bottom=bottom)
    inner = rbox(length-radial_width, width-radial_width, height+2, radius-radial_width/2, bottom=bottom-1)
    return outer.cut(inner)

def up(z): return Z0+z

def bbox(shape):
    b=shape.BoundingBox()
    return {key:round(getattr(b,key),6) for key in ('xmin','xmax','ymin','ymax','zmin','zmax')}

# Slip-on band and removable-module cradle. Nominal positive clearances only;
# retention force, elasticity and production undercuts are not established.
band = (cq.Workplane('XY').circle(BAND_ID/2+BAND_T).circle(BAND_ID/2)
        .extrude(BAND_W).translate((0,0,-BAND_W/2)).rotate((0,0,0),(1,0,0),90))
cradle = rbox(MOD_L+2*CRADLE_MARGIN, MOD_W+2*CRADLE_MARGIN,
              CRADLE_TOP-CRADLE_BOTTOM, MOD_R+CRADLE_MARGIN, bottom=CRADLE_BOTTOM)
cradle = cradle.edges('>Z').fillet(CRADLE_EDGE_R)
pocket_bottom = Z0-CRADLE_FLOOR_CLEARANCE
pocket = rbox(MOD_L+2*CRADLE_CLEARANCE, MOD_W+2*CRADLE_CLEARANCE,
              CRADLE_TOP-CRADLE_LIP_H-pocket_bottom, MOD_R+CRADLE_CLEARANCE, bottom=pocket_bottom)
lip_opening = rbox(MOD_L+2*CRADLE_LIP_CLEARANCE, MOD_W+2*CRADLE_LIP_CLEARANCE,
                   MOD_H, MOD_R+CRADLE_LIP_CLEARANCE, bottom=CRADLE_TOP-CRADLE_LIP_H)
band = band.union(cradle).cut(pocket).cut(lip_opening)
band = band.cut(cylinder(ACOUSTIC_WINDOW_D, ACOUSTIC_CUT_H, x=PIEZO_X, bottom=ACOUSTIC_CUT_BOTTOM))

# Base: the acoustic recess is cut from the INSIDE, leaving the bottom membrane.
base = rbox(MOD_L, MOD_W, BASE_H, MOD_R, bottom=Z0)
base = base.cut(rbox(MOD_L-2*SHELL_T, MOD_W-2*SHELL_T, MOD_H,
                     MOD_R-SHELL_T, bottom=up(SHELL_T)))
base = base.cut(cylinder(PIEZO_D+2*PIEZO_CLEARANCE, SHELL_T-MEMBRANE_T+1,
                          x=PIEZO_X, bottom=up(MEMBRANE_T)))

# Shared rounded-rectangle gland stays entirely inside the nominal wall.
# Rectangular seal envelope + clearance: not a released O-ring gland design.
gland_width = SEAL_W+2*SEAL_RADIAL_CLEARANCE
gland_height = SEAL_H+2*SEAL_AXIAL_CLEARANCE
gland = rounded_ring(SEAL_CENTER_L, SEAL_CENTER_W, SEAL_CENTER_R,
                     gland_width, gland_height, up(BASE_H-gland_height/2))
base = base.cut(gland)
cap = rbox(MOD_L, MOD_W, MOD_H-BASE_H, MOD_R, bottom=up(BASE_H)).edges('>Z').fillet(CAP_EDGE_R)
cap = cap.cut(rbox(MOD_L-2*SHELL_T, MOD_W-2*SHELL_T, MOD_H-BASE_H-SHELL_T,
                   MOD_R-SHELL_T, bottom=up(BASE_H)))
cap = cap.cut(gland)
cap = cap.cut(cylinder(BTN_D, MOD_H+BTN_H, x=BTN_X, bottom=Z0))
# Through aperture for display body, wider stepped recess for a sealed window.
cap = cap.cut(rbox(DISPLAY_L+2*DISPLAY_CLEARANCE, DISPLAY_W+2*DISPLAY_CLEARANCE,
                  MOD_H+1, DISPLAY_R+DISPLAY_CLEARANCE, x=DISPLAY_X, y=DISPLAY_Y, bottom=Z0))
cap = cap.cut(rbox(WINDOW_L+2*WINDOW_CLEARANCE, WINDOW_W+2*WINDOW_CLEARANCE,
                  WINDOW_T+1, WINDOW_R+WINDOW_CLEARANCE, x=DISPLAY_X, y=DISPLAY_Y, bottom=up(WINDOW_Z)))

button = cylinder(BTN_FLANGE_D, BTN_FLANGE_T, x=BTN_X, bottom=up(BTN_FLANGE_Z))
button = button.union(cylinder(BTN_STEM_D, MOD_H+BTN_H-BTN_FLANGE_Z-BTN_FLANGE_T,
                               x=BTN_X, bottom=up(BTN_FLANGE_Z+BTN_FLANGE_T)))
button = button.edges('>Z').fillet(BTN_EDGE_R)
plunger = cylinder(PLUNGER_D, BTN_FLANGE_Z-PLUNGER_Z, x=BTN_X, bottom=up(PLUNGER_Z))
pcb = rbox(PCB_L, PCB_W, PCB_T, PCB_R, x=PCB_X, bottom=up(PCB_Z))
battery = rbox(BAT_L, BAT_W, BAT_T, BAT_R, x=BAT_X, bottom=up(BAT_Z))
motor = cylinder(MOTOR_D, MOTOR_T, x=MOTOR_X, bottom=up(MOTOR_Z))
piezo = cylinder(PIEZO_D, PIEZO_T, x=PIEZO_X, bottom=up(PIEZO_Z))
coil = (cq.Workplane('XY').circle(COIL_OD/2).circle(COIL_ID/2).extrude(COIL_T).translate((COIL_X,0,up(COIL_Z))))
seal = rounded_ring(SEAL_CENTER_L, SEAL_CENTER_W, SEAL_CENTER_R, SEAL_W, SEAL_H, up(BASE_H-SEAL_H/2))
switch = cylinder(SWITCH_D, SWITCH_T, x=SWITCH_X, bottom=up(SWITCH_Z))
display = rbox(DISPLAY_L, DISPLAY_W, DISPLAY_T, DISPLAY_R, x=DISPLAY_X, y=DISPLAY_Y, bottom=up(DISPLAY_Z))
window = rbox(WINDOW_L, WINDOW_W, WINDOW_T, WINDOW_R, x=DISPLAY_X, y=DISPLAY_Y, bottom=up(WINDOW_Z))

# Stable original IDs except removal of the unsupported Qi-protocol filename.
parts = [
 ('01_band_silicone','Silicone band + cradle',band,'#303944',-16,'Slip-on band and positive-clearance cradle; retention and fit remain undefined.'),
 ('02_base_shell','Base shell',base,'#53606b',0,'Concept shell with an internal acoustic recess and rounded perimeter gland.'),
 ('03_piezo_transducer','Ultrasonic transducer envelope',piezo,'#d6ab41',7,'Single transducer envelope for the approximately 65 kHz ranging concept; component unselected.'),
 ('04_vibration_motor','Haptic motor envelope',motor,'#949da3',7,'Motor package envelope; actuator, mounting and waveform unselected.'),
 ('05_pcb','Main PCB envelope',pcb,'#287f56',15,'Unrouted electronics envelope with no claimed circuit implementation.'),
 ('06_tact_switch','Tactile switch envelope',switch,'#d0d6d7',22,'Switch envelope aligned with the separate plunger; travel and force undefined.'),
 ('07_battery_lipo','Battery envelope',battery,'#415f9e',26,'Unselected cell envelope; capacity, protection, swelling allowance and display runtime unresolved.'),
 ('08_inductive_coil','Inductive coil envelope',coil,'#bc7b43',35,'Annular coil envelope under the opaque button side; no charging protocol or efficiency specified.'),
 ('09_o_ring','Perimeter seal envelope',seal,'#25292e',43,'Rounded rectangular seal envelope with rectangular section and clearance; not a released gland or seal specification.'),
 ('10_top_cap','Top cap with window seat',cap,'#647987',71,'Sealed-cap concept with stepped display window seat and separate top-button aperture.'),
 ('11_button_dome','Top button',button,'#e76550',80,'Button above the cap; 2.2 mm modeled protrusion is not switch travel.'),
 ('12_display_body','Display body envelope',display,'#253a45',52,'Unselected display package; active area is a proposed 14 x 16 mm layout, not a component specification.'),
 ('13_display_window','Display window envelope',window,'#122b34',88,'Window on a stepped cap seat; seal, adhesive and optical properties remain unspecified.'),
 ('14_button_plunger','Button plunger envelope',plunger,'#a3acb3',60,'Separate plunger passes through coil center, contacting switch and button flange in the nominal model.')
]

# Write shared measured metadata before downstream exporters/renderers run.
assembly_shape = cq.Compound.makeCompound([part[2].val() for part in parts])
parameters = {key:value for key,value in list(globals().items()) if key.isupper() and isinstance(value,(int,float))}
manifest = {'revision':'D','units':'mm','parameters':parameters,'parts':[], 'assembly_bbox':bbox(assembly_shape)}
for part_id,label,solid,color,dz,description in parts:
    b=bbox(solid.val()); dimensions={axis:round(b[axis+'max']-b[axis+'min'],6) for axis in ('x','y','z')}
    manifest['parts'].append({'id':part_id,'label':label,'color':color,'dz':dz,'bbox':b,'description':description,'dimensions':dimensions})
(ROOT/'design-data.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('design-data.json ready: 14 part envelopes', flush=True)

# Export only after every shape and pair passes model consistency checks.
validation={'revision':'D','scope':'CAD solid consistency only; not physical or manufacturing validation','parts':[],'intersections':[]}
for part_id,label,solid,color,dz,description in parts:
    valid=solid.val().isValid(); count=len(solid.solids().vals())
    validation['parts'].append({'id':part_id,'valid':valid,'solid_count':count,'volume_mm3':solid.val().Volume()})
    if not valid or count != 1: raise RuntimeError(f'{part_id}: valid={valid}, solid_count={count}')
for left,right in itertools.combinations(parts,2):
    volume=left[2].val().intersect(right[2].val()).Volume()
    if volume > BOOLEAN_VOLUME_TOLERANCE: validation['intersections'].append({'a':left[0],'b':right[0],'volume_mm3':volume})
(QA/'cad-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
if validation['intersections']: raise RuntimeError('Unintended solid intersections: '+json.dumps(validation['intersections']))

assembly=cq.Assembly(name='DBA_RevD_Concept'); exploded=cq.Assembly(name='DBA_RevD_Exploded')
for part_id,label,solid,color,dz,description in parts:
    exporters.export(solid,str(CAD/(part_id+'.stl')),tolerance=STL_TOLERANCE,angularTolerance=STL_ANGULAR_TOLERANCE)
    exporters.export(solid,str(CAD/(part_id+'.step')))
    rgb=tuple(int(color[i:i+2],16)/255 for i in (1,3,5))
    assembly.add(solid,name=part_id,color=cq.Color(*rgb))
    exploded.add(solid.translate((0,0,dz)),name=part_id,color=cq.Color(*rgb))
assembly.save(str(CAD/'DBA_Band_assembly.step'))
exploded.save(str(CAD/'DBA_Band_exploded.step'))
# Remove only obsolete generated alias files; original source archive is preserved.
for suffix in ('.step','.stl'):
    old=CAD/('08_qi_receiver_coil'+suffix)
    if old.exists(): old.unlink()

svgopt=dict(width=900,height=700,marginLeft=24,marginTop=24,showAxes=False,strokeWidth=0.65,strokeColor=(25,40,52),hiddenColor=(160,170,180),showHidden=False)
exploded_shape=cq.Compound.makeCompound([p[2].translate((0,0,p[4])).val() for p in parts])
exporters.export(assembly_shape,str(DRAW/'iso_assembled.svg'),opt={**svgopt,'projectionDir':(1.2,-1.6,1.3)})
exporters.export(exploded_shape,str(DRAW/'iso_exploded.svg'),opt={**svgopt,'height':1100,'projectionDir':(1.2,-1.6,0.9)})
for view,direction in {'front':(0,-1,0),'top':(0,0,1),'side':(1,0,0)}.items():
    exporters.export(assembly_shape,str(DRAW/f'ortho_{view}.svg'),opt={**svgopt,'projectionDir':direction,'showHidden':True})
module_shape=cq.Compound.makeCompound([p[2].val() for p in parts if p[0]!='01_band_silicone'])
for filename,plane,offset in [('module_plan_section.dxf','XY',up(MOD_H/2)),('module_split_line.dxf','XY',up(BASE_H)),('module_front_section.dxf','XZ',0)]:
    section=cq.Workplane(plane).add(module_shape).section(offset)
    exporters.exportDXF(section,str(CAD/filename))

reopened=cq.importers.importStep(str(CAD/'DBA_Band_assembly.step'))
validation.update({'assembly_bbox':manifest['assembly_bbox'],'reopened_step_bbox':bbox(reopened.val()),'reopened_step_valid':reopened.val().isValid(),'reopened_step_solids':len(reopened.solids().vals())})
if not validation['reopened_step_valid'] or validation['reopened_step_solids']!=len(parts): raise RuntimeError('STEP reopen validation failed')
for key,value in validation['assembly_bbox'].items():
    if abs(value-validation['reopened_step_bbox'][key])>0.00001: raise RuntimeError('STEP bbox mismatch: '+key)
(QA/'cad-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({'assembly_bbox':manifest['assembly_bbox'],'valid_solids':len(parts),'unintended_intersections':len(validation['intersections']),'step_reopened':True}),flush=True)
