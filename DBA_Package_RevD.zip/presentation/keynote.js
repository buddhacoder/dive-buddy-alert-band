(function(){const b=document.getElementById('expandSpecs'),groups=[...document.querySelectorAll('.spec-group')];
b.onclick=()=>{const open=!groups.every(g=>g.open);groups.forEach(g=>g.open=open);b.setAttribute('aria-expanded',String(open));b.textContent=open?'Collapse all specifications':'Expand all specifications';};
groups.forEach(g=>g.addEventListener('toggle',()=>{const open=groups.every(g=>g.open);b.setAttribute('aria-expanded',String(open));b.textContent=open?'Collapse all specifications':'Expand all specifications';}));
})();
