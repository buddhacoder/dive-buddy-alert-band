(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  if (!$('dbaScreenA')) return;

  // Interface proposals, not firmware constants or measured hardware behavior.
  const FRESH_MS = 3000, UPDATE_MS = 1000, SESSION_MS = 300000;
  const canVibrate = typeof navigator.vibrate === 'function';
  let state = 'ready', caller = 'A', readingStatus = 'none', reading = null;
  let previousReading = null, trend = '', measuredAt = 0, sessionStarted = 0;
  let nextUpdate = 0, lastPulse = 0, phoneVibration = false, stoppedBy = null;
  let deliveryTimer = null, pairingTimer = null, nearTimer = null;
  let pulseTimers = [], lastEvent = '', latestScreen = null;
  const other = id => id === 'A' ? 'B' : 'A';
  const buddy = () => other(caller);
  const separation = () => Number($('dbaDistance').value);
  const available = () => $('dbaReply').checked && separation() <= 20;
  const isRanging = () => state === 'ranging';
  const batteryLow = id => $('dbaLowBattery').checked && id === caller;
  const numberText = n => Number.isInteger(n) ? String(n) : n.toFixed(1);

  function status(message) { $('dbaStatus').textContent = message; }
  function vibrate(pattern) {
    if (!phoneVibration || !canVibrate) return;
    try { navigator.vibrate(pattern); } catch (_) { phoneVibration = false; }
  }
  function clearPulses() {
    pulseTimers.forEach(clearTimeout); pulseTimers = [];
    ['A', 'B'].forEach(id => $('dbaScreen' + id).classList.remove('dba-pulsing'));
    if (canVibrate) { try { navigator.vibrate(0); } catch (_) { /* Browser may block haptics. */ } }
  }
  function pulse(id, pattern) {
    let elapsed = 0;
    pattern.forEach((duration, index) => {
      if (index % 2 === 0) {
        pulseTimers.push(setTimeout(() => $('dbaScreen' + id).classList.add('dba-pulsing'), elapsed));
        pulseTimers.push(setTimeout(() => $('dbaScreen' + id).classList.remove('dba-pulsing'), elapsed + duration));
      }
      elapsed += duration;
    });
    // Prune completed timer handles rather than growing the list for an entire session.
    pulseTimers.push(setTimeout(() => { pulseTimers = []; }, elapsed + 20));
    vibrate(pattern);
  }
  function clearReading() {
    reading = null; previousReading = null; trend = ''; measuredAt = 0;
    clearTimeout(nearTimer); nearTimer = null;
    clearPulses();
  }
  function clearSessionTimers() {
    clearTimeout(deliveryTimer); clearTimeout(pairingTimer); clearTimeout(nearTimer);
    deliveryTimer = pairingTimer = nearTimer = null;
    clearPulses();
  }
  function cadence(distance) {
    if (distance >= 15) return [4000, [120]];
    if (distance >= 10) return [2000, [120]];
    if (distance >= 5) return [1000, [120]];
    return [500, [120, 110, 120]];
  }

  function showScreen(id, label, value, hint, foot, tone = '', numeric = false) {
    $('dbaScreen' + id).dataset.tone = tone;
    $('dbaKicker' + id).textContent = label;
    const valueNode = $('dbaValue' + id);
    valueNode.dataset.number = String(numeric);
    valueNode.replaceChildren(document.createTextNode(value));
    if (numeric) { const unit = document.createElement('small'); unit.textContent = 'm'; valueNode.append(unit); }
    $('dbaHint' + id).textContent = hint;
    $('dbaFoot' + id).textContent = foot;
    if (id === caller) latestScreen = {
      state: readingStatus === 'none' ? state : state + ':' + readingStatus,
      label, value: value + (numeric ? ' m' : ''), subline: hint
    };
  }
  function button(id, text, disabled = false) {
    $('dbaButton' + id).textContent = id + ' · ' + text;
    $('dbaButton' + id).disabled = disabled;
  }
  function render() {
    const active = !['ready', 'unpaired', 'pairing'].includes(state);
    for (const id of ['A', 'B']) {
      const low = batteryLow(id);
      $('dbaBattery' + id).textContent = low ? '12%' : id === 'A' ? '80%' : '72%';
      $('dbaScreen' + id).dataset.low = String(low);
      $('dbaRole' + id).textContent = active ? id === caller ? 'Caller' : 'Buddy' : 'Paired with ' + other(id);
      $('dbaLink' + id).textContent = state === 'unpaired' ? 'NOT PAIRED' : state === 'pairing' ? 'PAIRING' : isRanging() && readingStatus !== 'fresh' ? 'LINK UNKNOWN' : 'PAIRED';
      $('dbaHold' + id).disabled = !(state === 'acknowledged' && id === caller && !low && available());
      showScreen(id, 'BUDDY ' + other(id), 'Ready', low ? 'Low battery' : 'Press to call', low ? 'Distance mode paused' : 'One paired buddy', low ? 'warning' : '');
      button(id, 'Short press to call');
    }

    if (state === 'unpaired' || state === 'pairing') {
      for (const id of ['A', 'B']) {
        $('dbaRole' + id).textContent = 'Surface setup';
        showScreen(id, 'PAIR ON THE SURFACE', state === 'pairing' ? 'Pairing' : 'Unpaired', state === 'pairing' ? 'Both buttons held' : 'Hold both buttons', state === 'pairing' ? 'Simulated 3-second gesture' : '3 seconds to pair');
        button(id, 'Pair first', true);
      }
    } else if (state === 'calling') {
      showScreen(caller, 'BUDDY ' + buddy(), 'Calling', 'Awaiting device receipt', 'No human response yet');
      button(caller, 'Short press to cancel'); button(buddy(), 'Waiting for call', true);
    } else if (state === 'call-failed') {
      showScreen(caller, 'BUDDY ' + buddy(), 'No reply', 'Delivery unconfirmed', 'Press to try again', 'warning');
      button(caller, 'Short press to retry');
    } else if (state === 'received') {
      showScreen(caller, 'BUDDY ' + buddy(), 'Received', 'Waiting for your buddy', 'Device receipt only');
      showScreen(buddy(), 'CALL FROM ' + caller, 'Buddy call', 'Press to acknowledge', 'Three attention pulses', 'attention');
      button(caller, 'Short press to cancel'); button(buddy(), 'Short press to acknowledge');
    } else if (state === 'ack-pending') {
      showScreen(caller, 'BUDDY ' + buddy(), 'No reply', 'Response unconfirmed', 'Waiting for connection', 'warning');
      showScreen(buddy(), 'CALL FROM ' + caller, 'Confirmed', 'Reply pending', 'Connection unavailable', 'warning');
      button(caller, 'Short press to cancel'); button(buddy(), 'Short press to cancel');
    } else if (state === 'acknowledged') {
      showScreen(caller, 'BUDDY ' + buddy(), 'Confirmed', batteryLow(caller) ? 'Battery low' : !available() ? 'Link unavailable' : 'Buddy acknowledged', batteryLow(caller) ? 'Distance mode paused' : !available() ? 'Distance mode unavailable' : 'Hold 1 s for distance', batteryLow(caller) || !available() ? 'warning' : '');
      showScreen(buddy(), 'CALL FROM ' + caller, 'Confirmed', 'Acknowledgement sent', 'Ready for distance session');
      button(caller, 'Short press to end'); button(buddy(), 'Short press to end');
    } else if (isRanging()) {
      if (readingStatus === 'fresh' && reading !== null) {
        showScreen(caller, 'DISTANCE TO ' + buddy(), numberText(reading), trend || 'First reading', 'Updated ' + Math.floor((performance.now() - measuredAt) / 1000) + ' s ago', '', true);
        showScreen(buddy(), 'DISTANCE TO ' + caller, numberText(reading), trend || 'First reading', 'Session active · press to stop', '', true);
      } else {
        const delayed = readingStatus === 'stale';
        showScreen(caller, 'DISTANCE TO ' + buddy(), '—', delayed ? 'Update delayed' : 'Distance unavailable', delayed ? 'Waiting for a fresh reading' : 'Waiting for a reply', 'warning');
        showScreen(buddy(), 'LINKED TO ' + caller, '—', delayed ? 'Update delayed' : 'Link unavailable', 'No current distance', 'warning');
      }
      button(caller, 'Short press to stop'); button(buddy(), 'Short press to stop');
    } else if (state === 'stop-pending') {
      showScreen(stoppedBy, 'SESSION ENDED', 'Stopped', 'Stopped on this band', 'Remote stop unconfirmed');
      const remote = other(stoppedBy);
      showScreen(remote, 'LINK UNKNOWN', '—', 'Remote stop unconfirmed', 'Press to stop locally', 'warning');
      button(stoppedBy, 'Stopped locally', true); button(remote, 'Short press to stop locally');
    }

    $('dbaPair').disabled = state !== 'unpaired';
    $('dbaReset').disabled = state === 'pairing';
    const currentStep = isRanging() ? 'range' : ['acknowledged', 'ack-pending'].includes(state) ? 'ack' : ['calling', 'received', 'call-failed'].includes(state) ? 'call' : 'ready';
    document.querySelectorAll('[data-dba-step]').forEach(node => {
      if (node.dataset.dbaStep === currentStep) node.setAttribute('aria-current', 'step');
      else node.removeAttribute('aria-current');
    });
    const eventValue = JSON.stringify(latestScreen);
    if (eventValue !== lastEvent) {
      lastEvent = eventValue;
      window.dispatchEvent(new CustomEvent('dba:display', {detail: {...latestScreen}}));
    }
  }

  function endSession(id, message, localOnly = false) {
    clearSessionTimers(); clearReading(); readingStatus = 'none';
    if (!localOnly && !available() && !['ready', 'unpaired', 'pairing', 'call-failed'].includes(state)) {
      state = 'stop-pending'; stoppedBy = id;
      status('Diver ' + id + ' stopped locally. The link is unavailable, so remote stop is unconfirmed. Stop the other band locally to end both sides.');
    } else {
      state = 'ready'; stoppedBy = null;
      status(message || 'Both bands stopped. Short press either band to start a new call.');
    }
    render();
  }
  function deliverAcknowledgement() {
    state = 'acknowledged';
    status('Diver ' + buddy() + ' acknowledged the call. ' + (batteryLow(caller) ? 'The caller battery is low; distance mode is paused in this demo.' : 'Diver ' + caller + ' can now hold for 1 second to request distance.'));
    clearPulses(); pulse(caller, [160]); render();
  }
  function startCall(id) {
    clearSessionTimers(); clearReading(); readingStatus = 'none';
    caller = id; state = 'calling'; stoppedBy = null;
    status('Diver ' + id + ' is calling ' + buddy() + '. Waiting for the other device to receive the call.');
    render();
    deliveryTimer = setTimeout(() => {
      if (state !== 'calling') return;
      if (!available()) {
        state = 'call-failed';
        status('No device reply. Delivery and human acknowledgement are unconfirmed. Restore the simulated link, then retry.');
      } else {
        state = 'received';
        status('Device ' + buddy() + ' received the call. Diver ' + buddy() + ' must short press to acknowledge; device receipt alone is not a human response.');
        pulse(buddy(), [240, 260, 240, 260, 240]);
      }
      render();
    }, 700);
  }
  function shortPress(id) {
    if (['ready', 'call-failed'].includes(state)) { startCall(id); return; }
    if (state === 'received' && id === buddy()) {
      if (available()) deliverAcknowledgement();
      else {
        clearPulses(); state = 'ack-pending';
        status('Diver ' + buddy() + ' acknowledged locally, but the link is unavailable. The caller has not received that acknowledgement.');
        render();
      }
      return;
    }
    if (state === 'stop-pending') { endSession(id, 'Both bands stopped locally. No active distance session.', true); return; }
    if (!['unpaired', 'pairing'].includes(state)) endSession(id);
  }
  function markUnavailable(kind) {
    const changed = readingStatus !== kind;
    clearReading(); readingStatus = kind;
    if (changed) status(kind === 'stale'
      ? 'Distance updates are delayed. The old number and trend are cleared; distance pulses are paused until a fresh reading arrives.'
      : 'No current reply. Distance and trend are unavailable; distance pulses are paused.');
    render();
  }
  function takeReading() {
    if (!isRanging()) return;
    if (!available()) { markUnavailable('unavailable'); return; }
    if ($('dbaPauseUpdates').checked) return;
    const wasUnknown = readingStatus !== 'fresh';
    reading = separation();
    trend = previousReading === null ? '' : reading < previousReading ? 'Nearer · simulated trend' : reading > previousReading ? 'Farther · simulated trend' : 'Steady · simulated trend';
    previousReading = reading; readingStatus = 'fresh'; measuredAt = performance.now();
    if (wasUnknown) status('Fresh distance received. Diver ' + caller + ' and diver ' + buddy() + ' both see separation. Either diver can short press to stop.');
    if (reading < 2 && !nearTimer) {
      clearPulses(); if ($('dbaCadence').checked) pulse(caller, [1000]);
      status('Below the 2 m concept threshold. The session ends after 1 second; proximity does not confirm visual contact.');
      nearTimer = setTimeout(() => endSession(caller, 'Session ended below 2 m. Visual contact and reunion are not confirmed.'), 1000);
    } else if (reading >= 2 && nearTimer) {
      clearTimeout(nearTimer); nearTimer = null; clearPulses();
    }
    render();
  }
  function startRanging(id) {
    if (id !== caller || state !== 'acknowledged' || batteryLow(caller) || !available()) return;
    clearSessionTimers(); clearReading(); state = 'ranging'; readingStatus = 'unavailable';
    sessionStarted = performance.now(); nextUpdate = sessionStarted + UPDATE_MS; lastPulse = 0;
    status('Distance requested. Waiting for a fresh simulated reading.');
    takeReading(); render();
  }
  function environmentChanged() {
    $('dbaDistanceValue').textContent = numberText(separation()) + ' m';
    if (state === 'ack-pending' && available()) { deliverAcknowledgement(); return; }
    if (isRanging()) {
      if (batteryLow(caller)) {
        endSession(caller, 'Caller battery low. Distance mode stopped in this proposed interface; a call remains available.'); return;
      }
      if (!available()) { markUnavailable('unavailable'); return; }
      if (!$('dbaPauseUpdates').checked && readingStatus !== 'fresh') { takeReading(); nextUpdate = performance.now() + UPDATE_MS; }
    }
    render();
  }

  for (const id of ['A', 'B']) {
    $('dbaButton' + id).addEventListener('click', () => shortPress(id));
    $('dbaHold' + id).addEventListener('click', () => startRanging(id));
  }
  $('dbaDistance').addEventListener('input', environmentChanged);
  ['dbaReply', 'dbaPauseUpdates', 'dbaLowBattery'].forEach(id => $(id).addEventListener('change', environmentChanged));
  $('dbaCadence').addEventListener('change', () => { clearPulses(); lastPulse = 0; });
  $('dbaHaptic').addEventListener('click', () => {
    if (!canVibrate) {
      $('dbaHapticNote').textContent = 'This browser does not provide vibration. Follow the visible screen pulses instead.';
      return;
    }
    phoneVibration = !phoneVibration;
    $('dbaHaptic').setAttribute('aria-pressed', String(phoneVibration));
    $('dbaHaptic').textContent = phoneVibration ? 'Disable phone vibration' : 'Enable phone vibration';
    $('dbaHapticNote').textContent = phoneVibration
      ? 'Phone vibration requested. This phone illustrates the band currently pulsing; device settings may suppress vibration.'
      : 'Phone vibration is off. Visible pulses remain available.';
    if (phoneVibration) vibrate([80]);
    else { try { navigator.vibrate(0); } catch (_) { /* No haptic access. */ } }
  });
  $('dbaReset').addEventListener('click', () => {
    clearSessionTimers(); clearReading(); state = 'unpaired'; readingStatus = 'none'; caller = 'A';
    $('dbaReply').checked = true; $('dbaPauseUpdates').checked = false; $('dbaLowBattery').checked = false;
    $('dbaDistance').value = '12'; $('dbaDistanceValue').textContent = '12 m';
    status('Both demo bands are unpaired. Pair on the surface by holding both buttons for 3 seconds.'); render();
  });
  $('dbaPair').addEventListener('click', () => {
    if (state !== 'unpaired') return;
    state = 'pairing'; status('Both top buttons are held for the simulated 3-second pairing gesture.'); render();
    pairingTimer = setTimeout(() => {
      if (!available()) { state = 'unpaired'; status('Pairing not confirmed. Make both demo devices available within the simulated link envelope, then pair again.'); }
      else { state = 'ready'; status('Pairing complete. Both bands show ready. Short press either band to call its paired buddy.'); }
      render();
    }, 3000);
  });

  const tick = setInterval(() => {
    if (!isRanging()) return;
    const now = performance.now();
    if (now - sessionStarted >= SESSION_MS) { endSession(caller, 'Five-minute session timeout. Distance feedback stopped.'); return; }
    if (readingStatus === 'fresh' && now - measuredAt >= FRESH_MS) markUnavailable('stale');
    if (now >= nextUpdate) { nextUpdate = now + UPDATE_MS; takeReading(); }
    if (readingStatus === 'fresh' && reading !== null && reading >= 2 && $('dbaCadence').checked) {
      const [period, pattern] = cadence(reading);
      if (now - lastPulse >= period) { lastPulse = now; clearPulses(); pulse(caller, pattern); }
    }
    render();
  }, 100);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && !['ready', 'unpaired'].includes(state)) endSession(caller, 'Demo paused because the page was hidden. Both simulated bands are stopped; call again to restart.', true);
  });
  window.addEventListener('pagehide', () => {
    if (!['ready', 'unpaired'].includes(state)) endSession(caller, 'Demo paused. Call again to restart.', true);
    clearSessionTimers(); clearReading();
    // Keep the interval registered: browsers suspend it in the back/forward cache.
  });

  window.DBA_DISPLAY = {
    get state() { return state; },
    get caller() { return caller; },
    get readingStatus() { return readingStatus; },
    get distance() { return reading; },
    getScreen: () => latestScreen ? {...latestScreen} : null,
    stop: () => endSession(caller)
  };
  render();
})();
