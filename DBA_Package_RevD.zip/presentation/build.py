from pathlib import Path
import json,base64,html,re
R=Path(__file__).resolve().parent.parent
P=R/'presentation'
req=json.loads((P/'requirements.json').read_text())
model=(P/'model.generated.js').read_text()
design=json.loads((R/'design-data.json').read_text())
params=design['parameters']
assembly=design['assembly_bbox']
# Descriptions are rendered from the reviewed viewer metadata, not stale Rev A claims.
model=re.sub(r'"desc":\s*"(?:[^"\\]|\\.)*"', '"desc": "Concept component; see the reviewed part notes below."', model)
img=lambda name:'data:image/png;base64,'+base64.b64encode((R/'renders'/name).read_bytes()).decode()
rows=''.join('<tr><th scope="row">'+html.escape(x[0])+'</th><td><span class="status">'+html.escape(x[1])+'</span><p>'+html.escape(x[2])+'</p></td><td>'+html.escape(x[4])+'<small>'+html.escape(x[3])+'</small></td></tr>' for x in req)
groups=[('Interface & interaction',[6,7,8,9,10,21,23]),('Acoustics & direction',[3,4,11,22]),('Mechanical design',[1,5,14,15,16,17]),('Power & charging',[2,12,13]),('Product & commercial',[0,18,19,20])]
def grouped_rows(ids):
 return ''.join('<tr><th scope="row">'+html.escape(req[i][0])+'</th><td><span class="status">'+html.escape(req[i][1])+'</span><p>'+html.escape(req[i][2])+'</p></td><td><span class="mobile-col">Engineering notes</span>'+html.escape(req[i][4])+'<small>'+html.escape(req[i][3])+'</small></td></tr>' for i in ids)
reqgroups=''.join('<details class="spec-group"><summary>'+title+'<span>'+str(len(ids))+' items</span></summary><div class="table-scroll"><table class="requirements"><thead><tr><th>Area</th><th>Intent and status</th><th>Engineering notes / discipline</th></tr></thead><tbody>'+grouped_rows(ids)+'</tbody></table></div></details>' for title,ids in groups)
drawings=''.join('<figure><img src="data:image/svg+xml;base64,'+base64.b64encode((P/(name+'.svg')).read_bytes()).decode()+'" alt="'+alt+'"><figcaption>'+caption+'</figcaption></figure>' for name,alt,caption in [
('module',f"Current display module: {params['MOD_L']:g} by {params['MOD_W']:g} mm; display window and top button.",'Display module · source dimensions · mm'),
('band',f"Band front: {params['BAND_ID']:g} mm wrist opening, {assembly['zmax']-assembly['zmin']:.1f} mm overall height.",'Display assembly · source dimensions · mm'),
('section','Section through current display, sealed window, button plunger and offset receiver coil.','Module section · generated from current STL geometry · mm')])
template=(P/'page.html').read_text()
for a,b in {'__DISPLAY_EXPERIENCE__':(P/'display-experience.html').read_text(),'__REQ_ROWS__':rows,'__REQ_GROUPS__':reqgroups,'__DRAWINGS__':drawings,'__HERO__':img('hero_assembled.png'),'__MODEL__':model,'__JS__':'\n'.join((P/n).read_text() for n in ['atmosphere.js','display-surface.js','hero.js','viewer.js','display-experience.js','keynote.js']),'__CSS__':(P/'style.css').read_text()+'\n'+(P/'display-experience.css').read_text()}.items():template=template.replace(a,b)
for key in ['MOD_L','MOD_W','MOD_H','BTN_H','ACTIVE_L','ACTIVE_W']:
 template=template.replace('__'+key+'__',f"{params[key]:g}")
template=template.replace('__PART_COUNT__',str(len(design['parts'])))
template=template.replace('__OVERALL_H__',f"{assembly['zmax']-assembly['zmin']:.1f}")
assert not re.search(r'__[A-Z_]+__',template), 'Unexpanded template variable'
(R/'DBA_Interactive.html').write_text(template)
print('Built DBA_Interactive.html; embedded regenerated model and current drawings')
