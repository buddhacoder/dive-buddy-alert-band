"""Encode regenerated STL triangles using the established base64 int16 format."""
from pathlib import Path
import struct,json,base64,re,math,hashlib
R=Path(__file__).resolve().parent.parent

def triangles(path):
 raw=path.read_bytes()
 if len(raw)>=84 and len(raw)==84+50*struct.unpack_from('<I',raw,80)[0]:
  return [struct.unpack_from('<9f',raw,84+50*i+12) for i in range(struct.unpack_from('<I',raw,80)[0])]
 verts=[tuple(map(float,m)) for m in re.findall(rb'vertex\s+([-+.\deE]+)\s+([-+.\deE]+)\s+([-+.\deE]+)',raw)]
 if not verts or len(verts)%3:raise ValueError('Invalid STL: '+str(path))
 return [sum(verts[i:i+3],()) for i in range(0,len(verts),3)]

def main():
 d=json.loads((R/'design-data.json').read_text()); b=d['assembly_bbox']
 center=[(b[a+'min']+b[a+'max'])/2 for a in 'xyz']
 loaded=[(p,triangles(R/'cad'/(p['id']+'.stl'))) for p in d['parts']]
 scale=max(abs(v-center[j%3]) for _,ts in loaded for t in ts for j,v in enumerate(t))
 parts=[];worst=0
 for p,ts in loaded:
  values=[v-center[j%3] for t in ts for j,v in enumerate(t)]
  quant=[max(-32767,min(32767,round(v/scale*32767))) for v in values]
  worst=max(worst,max(abs(v-q/32767*scale) for v,q in zip(values,quant)))
  raw=struct.pack('<'+'h'*len(quant),*quant)
  parts.append({**p,'data':base64.b64encode(raw).decode(),'triangles':len(ts),'stl_sha256':hashlib.sha256((R/'cad'/(p['id']+'.stl')).read_bytes()).hexdigest()})
 m={'revision':d['revision'],'center':center,'scale':scale,'parameters':d['parameters'],'assembly_bbox':b,'parts':parts}
 (R/'presentation/model.generated.js').write_text('window.DBA_MODEL='+json.dumps(m,separators=(',',':'))+';\n')
 assert len(parts)==len(d['parts']) and worst<=scale/32767/2+1e-8
 (R/'output/qa/revd-mesh.json').write_text(json.dumps({'revision':d['revision'],'parts':len(parts),'triangles':sum(p['triangles'] for p in parts),'max_error_mm':worst,'scale':scale},indent=2))
 print('Encoded',len(parts),'regenerated parts; maximum coordinate error',round(worst,6),'mm')
if __name__=='__main__':main()
