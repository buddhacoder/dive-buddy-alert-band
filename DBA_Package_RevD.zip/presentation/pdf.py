from pathlib import Path
import json, html, shutil
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.lib.utils import ImageReader
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF
R=Path(__file__).resolve().parent.parent; P=R/'presentation'; O=R/'output/pdf'; O.mkdir(parents=True,exist_ok=True)
W,H=595.28,841.89; margin=44; ink='#172d40'; muted='#526779'; blue='#21638f'; red='#ab3928'
D=json.loads((R/'design-data.json').read_text()); assert D['revision']=='D' and D['units']=='mm'
K=D['parameters']; B=D['assembly_bbox']; N=len(D['parts'])
def val(key): return f'{K[key]:g}'
HOUSING=' x '.join(val(k) for k in ['MOD_L','MOD_W','MOD_H'])
DISPLAY=' x '.join(val(k) for k in ['DISPLAY_L','DISPLAY_W','DISPLAY_T'])
WINDOW=' x '.join(val(k) for k in ['WINDOW_L','WINDOW_W','WINDOW_T'])
ACTIVE=' x '.join(val(k) for k in ['ACTIVE_L','ACTIVE_W'])
OVERALL=f"{B['zmax']-B['zmin']:g}"; OD=f"{K['BAND_ID']+2*K['BAND_T']:g}"

normal=ParagraphStyle('body',fontName='Helvetica',fontSize=10.5,leading=16,textColor=HexColor(ink))
def ascii_text(s):
 for a,b in [('→',' to '),('–','-'),('—',' - '),('’',"'"),('“','"'),('”','"'),('×',' x '),('≈','approximately '),('−','-')]: s=s.replace(a,b)
 return s
class Doc:
 def __init__(self,name):
  self.c=canvas.Canvas(str(O/name),pagesize=(W,H)); self.n=0; self.y=0
  self.c.setTitle('Dive Buddy Alert Band - '+('Annotated Concept Views Rev D' if 'Annotated' in name else 'Concept & Engineering Brief Rev D')); self.c.setAuthor('Concept by Rafael')
 def page(self,title,sub=''):
  if self.n:self.c.showPage()
  self.n+=1; c=self.c; c.setFillColor(HexColor('#07111c')); c.rect(0,H-20,W,20,fill=1,stroke=0)
  c.setFillColor(HexColor(muted)); c.setFont('Helvetica',9); c.drawString(margin,H-44,'DIVE BUDDY ALERT BAND / CONCEPT REV D')
  self.y=H-74; self.para(title,24,28,bold=True); self.y-=6
  if sub:self.para(sub,10,15,color=muted)
  c.setStrokeColor(HexColor('#cfdae2')); c.line(margin,40,W-margin,40); c.setFont('Helvetica',8); c.setFillColor(HexColor(muted))
  c.drawString(margin,27,'Concept by Rafael | Concept only | September 2026'); c.drawRightString(W-margin,27,str(self.n))
 def para(self,s,size=10.5,leading=16,bold=False,color=ink):
  st=ParagraphStyle('p',parent=normal,fontSize=size,leading=leading,textColor=HexColor(color),fontName='Helvetica-Bold' if bold else 'Helvetica')
  p=Paragraph(ascii_text(s),st); _,h=p.wrap(W-2*margin,1000)
  if self.y-h<55:raise ValueError(f'Page {self.n} overflow at {s[:60]}')
  p.drawOn(self.c,margin,self.y-h); self.y-=h+12
 def image(self,path,maxh=240):
  ir=ImageReader(str(path)); w,h=ir.getSize(); ratio=min((W-2*margin)/w,maxh/h); dw,dh=w*ratio,h*ratio
  self.c.drawImage(ir,margin+(W-2*margin-dw)/2,self.y-dh,width=dw,height=dh,mask='auto'); self.y-=dh+16
 def svg(self,name,maxh=270):
  d=svg2rlg(str(P/(name+'.svg'))); ratio=min((W-2*margin)/d.width,maxh/d.height); d.scale(ratio,ratio); h=d.height*ratio
  renderPDF.draw(d,self.c,margin+(W-2*margin-d.width*ratio)/2,self.y-h); self.y-=h+15
 def screens(self):
  states=[('READY','BUDDY B','Paired','Battery 82%'),('CALLING','Sent','Waiting for reply','Battery 82%'),('RANGING','8 m','Getting closer','Fresh reading'),('LINK LOST','--','Distance unavailable','No current reading')]
  x=margin; width=(W-2*margin-18)/2; top=self.y
  for i,(label,value,detail,foot) in enumerate(states):
   xx=x+(i%2)*(width+18); yy=top-(i//2)*174
   self.c.setFillColor(HexColor('#07111c'));self.c.roundRect(xx,yy-152,width,152,12,fill=1,stroke=0)
   self.c.setFillColor(HexColor('#9bd8e6'));self.c.setFont('Helvetica-Bold',9);self.c.drawString(xx+17,yy-25,label)
   self.c.setFillColor(HexColor('#f0f4f7'));self.c.setFont('Helvetica-Bold',28);self.c.drawString(xx+17,yy-67,value)
   self.c.setFont('Helvetica',11);self.c.drawString(xx+17,yy-93,detail)
   self.c.setFillColor(HexColor('#b0c4d4'));self.c.setFont('Helvetica',9);self.c.drawString(xx+17,yy-128,foot)
  self.y=top-348
 def save(self):self.c.save();print(self.n,'pages created')
d=Doc('DBA_Design_Package_RevD.pdf')
d.page('Dive Buddy Alert Band','Paired underwater calls with visible distance feedback.')
d.image(R/'renders/hero_assembled.png',220)
d.para('Feel the call. See the distance.',18,24,True)
d.para('A slip-on wristband concept combines a paired tactile call with a small display. Vibration draws attention. The screen shows call status and a fresh distance estimate during ranging.')
d.para('Display and physical control',13,18,True)
d.para('A glanceable display sits beside the physical top button. Both divers can see the current separation and communication state. Inductive charging through the sealed cap and the removable module remain part of the design.')
d.para('The concept assembly includes a display body and window beside the top button. Nominal geometry defines the component envelopes. Window sealing, electrical integration, power consumption and underwater legibility require engineering development.',9.5,14,color=muted)
d.para('One wrist transducer provides distance, not direction. The band is an aid to buddy procedures, never a safety guarantee.',11,16,True,red)
d.page('User interaction','Proposed surface pairing and underwater button sequence.')
for title,body in [
('1 / Pair on the surface','Hold both buttons for 3 seconds. Each screen shows the paired buddy and local battery status. Address allocation and nearby-pair isolation require firmware definition.'),
('2 / Call','A short press on a ready band calls the paired buddy. B receives three alert pulses and a visible incoming call. A sees Calling, followed by Received by device only after a packet reply.'),
('3 / Acknowledge','B presses once to acknowledge the incoming call. A then sees Buddy acknowledged. A device reply confirms message delivery only. The separate button press communicates the buddy\'s response.'),
('4 / Range','A holds for 1 second to start ranging. Both screens show the latest valid distance and a trend derived from successive readings. A can use the proposed distance cadence alongside the screen.'),
('5 / Stop','During ranging, a short press on either band requests Stop. The proposed five-minute timeout and one-second burst then stop below 2 m remain. Neither a near reading nor an automatic stop confirms reunion.'),
('6 / Charge','Place the bands on an inductive dock. The display shows local charging status. There is no charging connector on the band. Dock alignment, thermal limits and charge completion require definition.')]:
 d.para(title,13,17,True); d.para(body,10,14.5)
d.page('The display','Proposed information hierarchy. Illustrative values and enlarged screen studies.')
d.screens()
d.para('A distance requires a fresh measurement',14,18,True)
d.para('During ranging, the distance takes visual priority. A trend appears only after enough valid readings. A missing or stale reply clears the distance and trend and stops proximity cadence. Reacquisition begins with a fresh reading, without reusing an old trend.')
d.para('Calling, device receipt and buddy acknowledgement remain separate states. Pair identity and battery stay available. Text accompanies status colors. The display uses the physical button rather than an underwater touchscreen.',10,15)
d.para('These screens specify proposed content and behavior. The 8 m distance and 82% battery are synthetic. Pixel layout, refresh timing, brightness, window size and underwater readability are not established.',9,13,color=muted)
d.page('Distance feedback','Acoustic range, visual trend and optional caller cadence.')
for a,b in [('15-20 m / valid reply','One pulse every 4 seconds.'),('10-15 m','One pulse every 2 seconds.'),('5-10 m','One pulse every second.'),('2-5 m','A double pulse every 0.5 seconds.'),('Below 2 m','One-second burst, then stop. Proximity does not confirm visual contact.'),('Lost or stale reply','Distance unavailable. Clear the distance and trend and stop proximity pulses.')]: d.para('<b>'+a+'</b> - '+b,10,14)
d.para('Distance and orientation',14,19,True)
d.para('The proposed single transducer estimates separation. A range of 8 m does not establish whether the buddy is left, right, above or below. Relative bearing requires a separate sensing architecture. Exchanging device headings alone would not establish the bearing between divers, and wrist heading need not match swimming direction.')
d.para('The acoustic exchange',14,19,True)
d.para('Approximately 65 kHz ultrasonic two-way time-of-flight. Proposed calculation: <b>d = (round-trip time - fixed reply delay) x sound speed / 2</b>. At 1,500 m/s with an assumed 2 ms reply delay, 20 m gives approximately 26.7 ms propagation round trip and 28.7 ms total exchange time.',10,14)
d.para('20 m range, approximately ±0.3 m distance performance and nominal 1 Hz exchange are targets or assumptions. No measured performance is supplied. Timing resolution does not establish accuracy. Multipath, body shadowing and environmental variation remain unresolved.',9.5,14)
d.page('Dimensions & form','Rev D concept geometry. Nominal dimensions in millimetres, without manufacturing tolerances.')
d.svg('module',245); d.svg('band',245)
d.para(f"The {HOUSING} mm housing excludes the {val('BTN_H')} mm button protrusion. Overall assembly height is {OVERALL} mm. The band retains a {val('BAND_ID')} mm relaxed opening, {OD} mm outside diameter, {val('BAND_W')} mm axial width and {val('BAND_T')} mm radial wall. These are modeled envelopes, not physical fit or structural verification.",9.5,14)
d.page('Display & internal layout','Display window, button plunger and receiver-coil arrangement.')
d.svg('section',260)
d.para('Display beside the top button',14,19,True)
d.para(f'The display body occupies a nominal {DISPLAY} mm envelope beneath an {WINDOW} mm window. The proposed active area is {ACTIVE} mm. The display sits on the left of the top cap and the physical button on the right. Optical readability, sealing and electrical interconnects remain unresolved.',10,14.5)
d.para('Inductive charging through the cap',14,19,True)
d.para(f"The receiver coil sits beneath the opaque button side, away from the display window. A nominal {val('COIL_OD')} mm outside diameter, {val('COIL_ID')} mm centre opening and {val('COIL_T')} mm thickness provide a concept envelope around the button plunger. Dock alignment, ferrite, thermal behavior and charging efficiency require engineering definition.",10,14.5)
d.para(f'The assembly contains {N} parts, including the display body, window and button plunger. Geometric clearances do not establish complete packaging: seals, adhesives, flex cables, wiring, pressure deflection and assembly access still require development. The sealed module remains removable from the silicone band.',9.5,14)
req=json.loads((P/'requirements.json').read_text())
for j in range(0,len(req),5):
 group=req[j:j+5]; d.page('Engineering specification',f'Register {j+1}-{j+len(group)} of {len(req)}. Design decisions, performance targets and pending definition.')
 for area,status,intent,owner,question in group:
  d.para(html.escape(area+' / '+status),12,15,True,blue)
  d.para(html.escape(intent),9,12.5)
  d.para('<b>Pending definition:</b> '+html.escape(question)+'<br/><b>Discipline:</b> '+html.escape(owner),8.8,12.2)
d.page('Paired kit & commercial assumptions','Original cost basis and the scope of the display revision.')
d.para('Proposed offer',15,20,True)
d.para('Two bands with one shared inductive dock for recreational buddy pairs. Instructors and dive shops are potential channels. Customer demand and the value of a separate wrist device remain unvalidated.')
d.para('Rev A baseline economics',15,20,True)
d.para('Rev A gives a retail target of <b>$179-199 per pair</b> and a desk cost estimate of approximately <b>$43 per band / $86 per pair</b> at 5,000 pairs, with <b>±30% uncertainty</b>. The estimate allocates the dock across the pair. It excludes tooling, non-recurring engineering, freight and duty.')
d.para('The display variant has no revised cost estimate or retail target. The screen, window, seals, control electronics and power requirements change the cost basis. Rev A figures do not price the Rev D design.',11,16,True,red)
d.para('Performance scope',15,20,True)
d.para('The Rev A four 60-minute dives per charge and approximately 28 g assembled mass remain historical targets. The display variant has no established runtime or mass. The display load must enter a complete energy budget. The current housing dimensions describe the Rev D CAD envelope only.')
d.para('Development status',15,20,True)
d.para(f'Rev D provides a {N}-part parametric concept assembly with a display and window, coordinated drawings and the proposed interface. Acoustic performance, pressure sealing, manufacturing readiness, customer demand, certification and intellectual-property clearance remain unestablished.')
d.page('Design files','Current presentation, drawings and parametric source.')
for a,b in [
('DBA_Interactive.html','Rev D product presentation with the display assembly, interactive two-diver demonstration, coordinated dimensions and full specification. Screen values are simulated. Three.js loads from its existing CDN.'),
('DBA_Design_Package_RevD.pdf','Current concept, proposed display and button behavior, technical specification and engineering review notes.'),
('DBA_Product_Overview_RevD.pptx','Editable product overview with speaker notes. Illustrative screens communicate the proposed interface.'),
('DBA_Annotated_Views_RevD.pdf','Three coordinated annotated views of the current display assembly. Nominal concept dimensions include the housing, band, display window and internal section.'),
('cad/, drawings/ and renders/',f'Regenerated STEP, STL, DXF, drawings and render assets for the {N}-part Rev D assembly. Nominal dimensions derive from the parametric source.'),
('dba_cad.py, render.py, drawing_sheet.py','Parametric design and generation scripts. Named parameters define the geometry, which supplies the drawings, renders and embedded meshes.'),
('presentation/','Editable presentation source and requirements register. Regenerated mesh data uses the existing base64 int16 format. The generated design-data.json records dimensions and component envelopes.'),
('Legacy references','Earlier packages remain historical references. Rev D governs the current geometry, drawings and proposed display interaction.')]: d.para('<b>'+a+'</b><br/>'+b,9.3,13)
d.para('Geometry changes begin in dba_cad.py, followed by regeneration of CAD, renders, drawings and embedded meshes. Keep the model, drawings and presentation on the same revision.',10,15,True)
d.save()
shutil.copy2(O/'DBA_Design_Package_RevD.pdf',R/'DBA_Design_Package_RevD.pdf')

v=Doc('DBA_Annotated_Views_RevD.pdf')
for name,title,note in [
 ('module','Module / top view',f"{val('MOD_L')} x {val('MOD_W')} mm nominal housing. The top window is {val('WINDOW_L')} x {val('WINDOW_W')} mm with a {ACTIVE} mm proposed active area. The display sits beside the physical button. Housing height is {val('MOD_H')} mm plus {val('BTN_H')} mm button protrusion."),
 ('band','Band / front section',f"{val('BAND_ID')} mm relaxed opening, {OD} mm nominal band outside diameter, {val('BAND_W')} mm axial width and {val('BAND_T')} mm radial wall. Overall assembly height is {OVERALL} mm including the button. Wrist coverage and stretched fit are not demonstrated."),
 ('section','Module / centre section','The section shows the display body and window, button plunger and receiver coil under the opaque button side. These nominal envelopes do not establish sealing, electrical integration, acoustic performance or manufacturing readiness.')]:
 v.page(title,'DBA annotated concept views / Revision D')
 v.svg(name,470);v.para(note)
 v.para('Source: regenerated dba_cad.py and design-data.json. Nominal concept dimensions in millimetres. Views are not to scale. No manufacturing tolerances or pressure rating are assigned.',9,13)
v.save()
shutil.copy2(O/'DBA_Annotated_Views_RevD.pdf',R/'DBA_Annotated_Views_RevD.pdf')
