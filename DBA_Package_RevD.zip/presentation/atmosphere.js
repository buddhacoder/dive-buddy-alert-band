// Shared display-only normal smoothing. Vertex coordinates and mesh payloads remain unchanged.
window.DBA_smoothNormals=function(g){
 g.computeVertexNormals();const p=g.attributes.position,n=g.attributes.normal,buckets=new Map();
 for(let i=0;i<p.count;i++){const k=[p.getX(i),p.getY(i),p.getZ(i)].map(v=>Math.round(v*10000)).join(',');if(!buckets.has(k))buckets.set(k,[]);buckets.get(k).push(i);}
 const out=new Float32Array(n.array.length);
 for(const ids of buckets.values())for(const i of ids){let x=0,y=0,z=0;for(const j of ids){if(n.getX(i)*n.getX(j)+n.getY(i)*n.getY(j)+n.getZ(i)*n.getZ(j)>.65){x+=n.getX(j);y+=n.getY(j);z+=n.getZ(j);}}const l=Math.hypot(x,y,z)||1;out[i*3]=x/l;out[i*3+1]=y/l;out[i*3+2]=z/l;}
 g.setAttribute('normal',new THREE.BufferAttribute(out,3));
};
(function(){
 const root=document.documentElement,reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;let queued=false;
 function update(){queued=false;const max=Math.max(1,document.documentElement.scrollHeight-innerHeight),progress=Math.min(1,Math.max(0,scrollY/max));const depth=Math.min(1,scrollY/(innerHeight*3));root.style.setProperty('--descent',progress);root.style.setProperty('--light',1-depth*.9);root.style.setProperty('--water-top',`rgb(${Math.round(17-depth*14)},${Math.round(60-depth*49)},${Math.round(77-depth*53)})`);root.style.setProperty('--water-bottom',`rgb(${Math.round(7-depth*4)},${Math.round(28-depth*21)},${Math.round(43-depth*26)})`);root.style.setProperty('--particle-shift',reduced?'0px':`${-progress*140}px`);document.getElementById('descentMarker').style.top=(progress*100)+'%';}
 addEventListener('scroll',()=>{if(!queued){queued=true;requestAnimationFrame(update);}},{passive:true});addEventListener('resize',update);update();
})();
