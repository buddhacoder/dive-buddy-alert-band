"""Package one consistent Rev D release and preserve the original source archive."""
from pathlib import Path
import zipfile,json
R=Path(__file__).resolve().parent.parent
required=['DBA_Interactive.html','presentation.html','DBA_Design_Package_RevD.pdf','DBA_Product_Overview_RevD.pptx','DBA_Annotated_Views_RevD.pdf','README.txt','README_RevD.txt','design-data.json']
for name in required:
 if not (R/name).is_file():raise FileNotFoundError(name)
d=json.loads((R/'design-data.json').read_text());assert d['revision']=='D'
with zipfile.ZipFile(R/'DBA_Package_RevD.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in required+['dba_cad.py','render.py','drawing_sheet.py']:z.write(R/name,name)
 for folder in ['cad','drawings','renders','hub-assets']:
  for p in sorted((R/folder).rglob('*')):
   if p.is_file() and not p.name.startswith('.'):z.write(p,p.relative_to(R))
 z.write(R.parent/'DBA_Package_RevA.zip','legacy/DBA_Package_RevA.zip')
 for n in ['DBA_Design_Package_RevB.pdf','DBA_Design_Package_RevC.pdf']:
  z.write(R/n,'legacy/'+n)
 for p in sorted((R/'presentation').iterdir()):
  if p.is_file() and p.suffix in {'.html','.css','.js','.py','.json','.svg'} and p.name not in {'RevA_Interactive.original.html','model.original.js','sim.js'}:
   z.write(p,p.relative_to(R))
 z.write(R/'presentation/deck-build/build.mjs','presentation/deck-build/build.mjs')
print('Created DBA_Package_RevD.zip')
