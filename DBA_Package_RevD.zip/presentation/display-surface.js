// Shared screen finish for the actual generated display-window part in both viewers.
(function(){
'use strict';if(!window.THREE)return;
const c=document.createElement('canvas');c.width=560;c.height=640;
const x=c.getContext('2d'),texture=new THREE.CanvasTexture(c);texture.encoding=THREE.sRGBEncoding;
let revision=0;
function paint(detail={}){
 x.fillStyle='#031014';x.fillRect(0,0,560,640);x.textAlign='center';
 x.fillStyle='#b1ced0';x.font='500 42px sans-serif';x.fillText((detail.label||'BUDDY B').toUpperCase(),280,115);
 const value=detail.value||'READY';x.fillStyle='#f1fcfa';x.font=`600 ${value.length>7?69:104}px sans-serif`;x.fillText(value,280,365);
 x.fillStyle='#bedbd9';x.font='500 35px sans-serif';x.fillText((detail.subline||'PAIRED').slice(0,23),280,510);
 texture.needsUpdate=true;revision++;
}
paint();window.addEventListener('dba:display',e=>paint(e.detail));
function material(p,g){
 const m=new THREE.MeshStandardMaterial({color:new THREE.Color('#123039').convertSRGBToLinear(),roughness:.23,metalness:.18,transparent:true});
 const b=p.bbox,P=DBA_MODEL.parameters,center=DBA_MODEL.center;
 const screenX=(b.xmin+b.xmax)/2-center[0],screenY=(b.ymin+b.ymax)/2-center[1],top=b.zmax-center[2];
 m.onBeforeCompile=s=>{
  s.uniforms.dbaScreen={value:texture};
  s.vertexShader='varying vec3 vDbaPosition;\n'+s.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvDbaPosition=position;');
  s.fragmentShader='uniform sampler2D dbaScreen;\nvarying vec3 vDbaPosition;\n'+s.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   vec2 dbaUV=(vDbaPosition.xy-vec2(${screenX.toFixed(5)},${screenY.toFixed(5)}))/vec2(${Number(P.ACTIVE_L).toFixed(5)},${Number(P.ACTIVE_W).toFixed(5)})+0.5;
   float dbaMask=step(0.,dbaUV.x)*step(dbaUV.x,1.)*step(0.,dbaUV.y)*step(dbaUV.y,1.)*step(${(top-.015).toFixed(5)},vDbaPosition.z);
   vec3 dbaColor=texture2D(dbaScreen,dbaUV).rgb;
   diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.005),dbaMask);
   totalEmissiveRadiance+=dbaColor*dbaMask*.9;`);
 };
 return m;
}
window.DBA_SCREEN_MATERIAL={material,get revision(){return revision;}};
})();
