"""Build the public presentation hub and its self-contained conversation preview."""
from pathlib import Path
from PIL import Image
import base64, copy, html, json, shutil, zipfile
from xml.etree import ElementTree as ET

R = Path(__file__).resolve().parent.parent
P = R / 'presentation'
A = R / 'hub-assets'
A.mkdir(exist_ok=True)
BASE = 'https://buddhacoder.github.io/dive-buddy-alert-band/'
INLINE = Path('/Users/macstudiodaddy/.codex/visualizations/2026/09/08/01a08303-45b0-7c90-9c53-61ecb45951e6/dba-presentation-hub.html')
data = {'base': BASE, 'slides': [], 'drawings': []}
ns = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'}
deck = zipfile.ZipFile(R / 'DBA_Product_Overview_RevD.pptx')
for i in range(1, 10):
    source = P / 'deck-build' / 'rev-d' / f'slide-{i}.png'
    destination = A / f'slide-{i}.webp'
    with Image.open(source) as image:
        image.convert('RGB').save(destination, 'WEBP', lossless=True, method=6)
    slide = ET.fromstring(deck.read(f'ppt/slides/slide{i}.xml'))
    text = [''.join(t.text or '' for t in p.findall('.//a:t', ns)) for p in slide.findall('.//a:p', ns)]
    text = [t for t in text if t.strip()]
    titles = ['Dive Buddy Alert Band','Haptics and a glanceable display','Calling and acknowledgement','Four display states','Distance and direction','The band and its display','Acoustics and power','Paired kit economics','Dive Buddy Alert Band']
    data['slides'].append({'title': titles[i-1], 'text': text, 'image': f'hub-assets/slide-{i}.webp', 'full': BASE + f'hub-assets/slide-{i}.webp'})
d = json.loads((R / 'design-data.json').read_text())
k = d['parameters']
for name, title, text in [
    ('module', 'Module · top view', [f"Housing: {k['MOD_L']:g} × {k['MOD_W']:g} mm. Window: {k['WINDOW_L']:g} × {k['WINDOW_W']:g} mm. Active display: {k['ACTIVE_L']:g} × {k['ACTIVE_W']:g} mm.", 'A display window beside the physical top button. Nominal concept dimensions.']),
    ('band', 'Band · front section', [f"Overall height: {d['assembly_bbox']['zmax']-d['assembly_bbox']['zmin']:.1f} mm. Relaxed wrist opening: {k['BAND_ID']:g} mm. Outside diameter: {k['BAND_ID']+2*k['BAND_T']:g} mm.", f"Band width: {k['BAND_W']:g} mm. Radial wall: {k['BAND_T']:g} mm. Nominal concept dimensions."]),
    ('section', 'Module · internal section', [f"Housing: {k['MOD_L']:g} × {k['MOD_W']:g} × {k['MOD_H']:g} mm. Button protrusion: {k['BTN_H']:g} mm additional.", 'Display and window beside the button. The plunger passes through the receiver coil centre opening. Modeled component envelopes do not establish assembly, sealing or physical component fit.'])
]:
    shutil.copy2(P / f'{name}.svg', A / f'{name}.svg')
    data['drawings'].append({'title': title, 'text': text, 'image': f'hub-assets/{name}.svg', 'full': BASE + f'hub-assets/{name}.svg'})
template = (P / 'hub.fragment.html').read_text()
def fragment(payload):
    result = template
    replacements = {
        '__FIRST_IMAGE__': payload['slides'][0]['image'],
        '__FIRST_FULL__': payload['slides'][0]['full'],
        '__FIRST_TEXT__': ''.join('<p>'+html.escape(t)+'</p>' for t in payload['slides'][0]['text']),
        '__SLIDE_OPTIONS__': ''.join(f'<option value="{i}">{i+1}. {html.escape(s["title"])}</option>' for i,s in enumerate(payload['slides'])),
        '__HUB_DATA__': json.dumps(payload, ensure_ascii=False).replace('<', '\\u003c'),
        '__HUB_JS__': (P / 'hub.js').read_text()
    }
    for a,b in replacements.items(): result = result.replace(a,b)
    return result
public = (P / 'hub-shell.html').read_text().replace('__FRAGMENT__', fragment(data))
(R / 'presentation.html').write_text(public)
inline = copy.deepcopy(data)
for page in inline['slides'] + inline['drawings']:
    asset = R / page['image']
    mime = 'image/webp' if asset.suffix == '.webp' else 'image/svg+xml'
    page['image'] = f'data:{mime};base64,' + base64.b64encode(asset.read_bytes()).decode()
inline_fragment = fragment(inline)
assert len(inline_fragment.encode()) < 1_000_000, 'Conversation preview must remain below 1 MB'
INLINE.parent.mkdir(parents=True, exist_ok=True)
INLINE.write_text(inline_fragment)
print(f'Built presentation.html and conversation preview ({len(inline_fragment.encode())} bytes).')
print('9 current slides, 3 current drawings, 5 download destinations.')
