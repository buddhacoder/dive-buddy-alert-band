"""Current concept views derived from the regenerated CAD manifest and STL sections."""
from pathlib import Path
import json,html,math
from embed_mesh import triangles
R=Path(__file__).resolve().parent.parent;P=R/'presentation'
D=json.loads((R/'design-data.json').read_text());A=D['parameters'];B=D['assembly_bbox'];parts={p['id']:p for p in D['parts']}
INK='#173041';BLUE='#21648f';MUTED='#526d7c'
def text(x,y,t,size=15,color=INK,anchor='start',rotate=None):
 tr='' if rotate is None else f' transform="rotate({rotate} {x} {y})"'
 return f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" fill="{color}" text-anchor="{anchor}"{tr}>{html.escape(str(t))}</text>'
def line(x1,y1,x2,y2,c=INK):return f'<path d="M{x1:.2f},{y1:.2f}L{x2:.2f},{y2:.2f}" fill="none" stroke="{c}" stroke-width="1.2"/>'
def rect(x,y,w,h,fill='none',r=0,stroke=INK):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>'
def hdim(x1,x2,y0,y,label):
 return line(x1,y0,x1,y+5,BLUE)+line(x2,y0,x2,y+5,BLUE)+f'<path d="M{x1},{y}H{x2}" stroke="{BLUE}" marker-start="url(#a)" marker-end="url(#a)"/>'+text((x1+x2)/2,y-9,label,15,BLUE,'middle')
def vdim(x0,x,y1,y2,label):
 return line(x0,y1,x+5,y1,BLUE)+line(x0,y2,x+5,y2,BLUE)+f'<path d="M{x},{y1}V{y2}" stroke="{BLUE}" marker-start="url(#a)" marker-end="url(#a)"/>'+text(x+22,(y1+y2)/2,label,15,BLUE,'middle',-90)
def leader(x,y,x2,y2,label,anchor='start'):
 return line(x,y,x2,y2)+text(x2+(-5 if anchor=='end' else 5),y2-6,label,14,INK,anchor)
def save(name,body,w=760,h=620):
 head=f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><rect width="100%" height="100%" fill="#f7fafc"/><defs><marker id="a" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 10 5 0 10Z" fill="{BLUE}"/></marker></defs><g font-family="Arial, sans-serif">'
 footer=text(28,h-21,'DBA / REV D  |  NOMINAL mm  |  CONCEPT GEOMETRY - NOT A MANUFACTURING RELEASE',11)
 (P/(name+'.svg')).write_text(head+body+footer+'</g></svg>')

def section_loops(stem):
 # y=0.003 avoids coincident facets without a visible section offset.
 plane=.003; edges=[]
 for t in triangles(R/'cad'/(stem+'.stl')):
  vs=[t[i:i+3] for i in [0,3,6]];cross=[]
  for u,v in zip(vs,vs[1:]+vs[:1]):
   if (u[1]-plane)*(v[1]-plane)<0:
    f=(plane-u[1])/(v[1]-u[1]);cross.append((round(u[0]+f*(v[0]-u[0]),4),round(u[2]+f*(v[2]-u[2]),4)))
  if len(cross)==2 and cross[0]!=cross[1]:edges.append(tuple(cross))
 links={}
 for i,(u,v) in enumerate(edges):links.setdefault(u,[]).append(i);links.setdefault(v,[]).append(i)
 used=set();loops=[]
 for i,(u,v) in enumerate(edges):
  if i in used:continue
  used.add(i);seq=[u,v]
  while seq[-1]!=seq[0]:
   options=[j for j in links[seq[-1]] if j not in used]
   if not options:break
   j=options[0];used.add(j);q=edges[j];seq.append(q[1] if q[0]==seq[-1] else q[0])
  loops.append(seq)
 return loops

def slice_shape(stem,project,fill,stroke=INK):
 paths=[]
 for loop in section_loops(stem):
  points=[project(*p) for p in loop];paths.append('M'+'L'.join(f'{x:.2f},{y:.2f}' for x,y in points)+('Z' if loop[0]==loop[-1] else ''))
 return f'<path d="{" ".join(paths)}" fill="{fill}" fill-rule="evenodd" stroke="{stroke}" stroke-width="1.1" stroke-linejoin="round"/>'

# Plan view: parametric cap, actual window and button envelope, active screen area.
s=text(28,40,'DISPLAY MODULE / TOP VIEW',25)+text(28,69,'Window and top button in the current parametric assembly.',15,MUTED)
scale=9;cx,cy=350,292;L,W=A['MOD_L']*scale,A['MOD_W']*scale
s+=rect(cx-L/2,cy-W/2,L,W,'#dce5e9',A['MOD_R']*scale)
wx=cx+A['DISPLAY_X']*scale;wy=cy-A.get('DISPLAY_Y',0)*scale
s+=rect(wx-A['WINDOW_L']*scale/2,wy-A['WINDOW_W']*scale/2,A['WINDOW_L']*scale,A['WINDOW_W']*scale,'#668c94',A['WINDOW_R']*scale)
s+=rect(wx-A['ACTIVE_L']*scale/2,wy-A['ACTIVE_W']*scale/2,A['ACTIVE_L']*scale,A['ACTIVE_W']*scale,'#092530',5)
s+=text(wx,wy-25,'BUDDY',12,'#c5e0e1','middle')+text(wx,wy+7,'READY',22,'#f5ffff','middle')+text(wx,wy+41,'Illustrative UI',10,'#c5e0e1','middle')
bx=cx+A['BTN_X']*scale
s+=f'<circle cx="{bx}" cy="{cy}" r="{A["BTN_D"]*scale/2}" fill="#67808d" stroke="{INK}"/><circle cx="{bx}" cy="{cy}" r="{A["BTN_STEM_D"]*scale/2}" fill="#dc7563" stroke="{INK}"/>'
s+=hdim(cx-L/2,cx+L/2,cy-W/2,112,f'{A["MOD_L"]:.1f} housing')+vdim(cx+L/2,605,cy-W/2,cy+W/2,f'{A["MOD_W"]:.1f} housing')
s+=leader(wx,wy+A['WINDOW_W']*scale/2,wx,490,f'{A["WINDOW_L"]:g} x {A["WINDOW_W"]:g} window')
s+=leader(bx,cy+A['BTN_STEM_D']*scale/2,bx,470,f'{A["BTN_D"]:g} button aperture')
s+=text(70,545,f'{A["ACTIVE_L"]:g} x {A["ACTIVE_W"]:g} active display area',16,BLUE)+text(70,570,'Screen and window sizes are concept parameters; readability is unverified.',13,MUTED)
save('module',s)

# Front section through current assembly: actual STL intersections show cradle and housing.
s=text(28,40,'DISPLAY ASSEMBLY / FRONT SECTION',25)+text(28,68,'Centre section from the regenerated STL geometry.',15,MUTED)
sk=4.4;cx=326;floor=509
project=lambda x,z:(cx+x*sk,floor-(z-B['zmin'])*sk)
for stem,col in [('01_band_silicone','#dce6eb'),('02_base_shell','#a8bbc7'),('10_top_cap','#c3d2da'),('13_display_window','#517984'),('11_button_dome','#d58373')]:s+=slice_shape(stem,project,col)
OD=A['BAND_ID']+2*A['BAND_T'];mid=project(0,0)[1]
s+=hdim(cx-A['BAND_ID']/2*sk,cx+A['BAND_ID']/2*sk,mid,mid,f'{A["BAND_ID"]:.1f} wrist opening')
s+=hdim(cx-OD/2*sk,cx+OD/2*sk,floor,549,f'{OD:.1f} band OD')
s+=vdim(cx+OD/2*sk,548,project(0,B['zmax'])[1],floor,f'{B["zmax"]-B["zmin"]:.1f} overall')
s+=text(28,580,f'Band width {A["BAND_W"]:g}  /  radial wall {A["BAND_T"]:g}  /  cradle width {B["ymax"]-B["ymin"]:g}',14,MUTED)
save('band',s)

# Actual mesh section, not a schematic made from stale component boxes.
s=text(28,40,'DISPLAY MODULE / CENTRE SECTION',25)+text(28,69,'Current STL section. Color identifies component envelopes.',15,MUTED)
sk=12;cx=370;floor=385
project=lambda x,z:(cx+x*sk,floor-(z-A['Z0'])*sk)
colors={'02_base_shell':'#c5d3dc','03_piezo_transducer':'#edd797','04_vibration_motor':'#acb7c0','05_pcb':'#8eb8a6','06_tact_switch':'#adbbc6','07_battery_lipo':'#a6badb','08_inductive_coil':'#d5a46e','09_o_ring':'#50616b','10_top_cap':'#c5d3dc','11_button_dome':'#de8b7a','12_display_body':'#284957','13_display_window':'#385e6d','14_button_plunger':'#d8a999'}
for stem,col in colors.items():s+=slice_shape(stem,project,col)
s+=hdim(cx-A['MOD_L']/2*sk,cx+A['MOD_L']/2*sk,floor,430,f'{A["MOD_L"]:.1f} housing')
s+=vdim(cx+A['MOD_L']/2*sk,838,project(0,A['Z0']+A['MOD_H'])[1],floor,f'{A["MOD_H"]:.1f} housing')
# Labels use separated vertical lanes and the actual bounding-box centers.
for stem,label,x2,y2 in [('13_display_window','Window',200,116),('11_button_dome','Top button',537,111),('08_inductive_coil','Coil',760,230),('14_button_plunger','Plunger',760,286),('05_pcb','PCB',40,331),('03_piezo_transducer','Transducer',40,386)]:
 b=parts[stem]['bbox'];anchor_x=(b['xmin']+b['xmax'])/2
 if stem=='08_inductive_coil':anchor_x=A['COIL_X']+(A['COIL_OD']+A['COIL_ID'])/4
 u,v=project(anchor_x,(b['zmin']+b['zmax'])/2);s+=leader(u,v,x2,y2,label)
for stem,label in [('12_display_body','Display'),('07_battery_lipo','Battery'),('04_vibration_motor','Motor')]:
 b=parts[stem]['bbox'];u,v=project((b['xmin']+b['xmax'])/2,(b['zmin']+b['zmax'])/2);s+=text(u,v+4,label,13,'#f4fafc' if stem=='12_display_body' else INK,'middle')
s+=text(28,477,'Coil is beneath the button side of the cap; the plunger passes through its centre opening.',14,MUTED)
s+=text(28,503,'Nominal clearances are modeled. Wiring, supports, sealing and charging efficiency remain undefined.',13,MUTED)
save('section',s,900,550)
print('Regenerated Rev D annotation SVGs from current parameters and STL sections')
