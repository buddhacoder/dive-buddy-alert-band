"""DBA-001 Rev D: current concept dimensions and STL-derived center sections.
No blanket tolerances, pressure certification or manufacturing release is implied.
"""
from pathlib import Path
import json
import itertools
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,FancyBboxPatch
from matplotlib.collections import LineCollection
from stl import mesh as stlmesh

ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'design-data.json').read_text()); P=DATA['parameters']; PARTS=DATA['parts']
OUT=ROOT/'drawings'; OUT.mkdir(exist_ok=True)
INK,DIM,MUTED='#193040','#17638b','#596c7b'
plt.rcParams['font.family']='DejaVu Sans'
CACHE={part['id']:stlmesh.Mesh.from_file(str(ROOT/'cad'/(part['id']+'.stl'))).vectors for part in PARTS}

def rrect(ax,x,y,w,h,r,**kw):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={r}',**kw))

def dimension(ax,a,b,label,offset=4,vertical=False):
    x1,y1=a; x2,y2=b
    if vertical:
        x=max(x1,x2)+offset
        ax.plot([x1,x],[y1,y1],color=DIM,lw=.6); ax.plot([x2,x],[y2,y2],color=DIM,lw=.6)
        ax.annotate('',(x,y1),(x,y2),arrowprops=dict(arrowstyle='<->',color=DIM,lw=.8))
        ax.text(x+1.1,(y1+y2)/2,label,rotation=90,ha='left',va='center',color=DIM,fontsize=8)
    else:
        y=max(y1,y2)+offset
        ax.plot([x1,x1],[y1,y],color=DIM,lw=.6); ax.plot([x2,x2],[y2,y],color=DIM,lw=.6)
        ax.annotate('',(x1,y),(x2,y),arrowprops=dict(arrowstyle='<->',color=DIM,lw=.8))
        ax.text((x1+x2)/2,y+1.0,label,ha='center',va='bottom',color=DIM,fontsize=8)

def prepare(ax,title,xlim,ylim):
    ax.set_title(title,loc='left',fontsize=12,color=INK,weight='bold',pad=20)
    ax.set_xlim(*xlim);ax.set_ylim(*ylim);ax.set_aspect('equal');ax.axis('off')

def section_segments(tris,axis,offset,coordinates,origin=(0,0)):
    segments=[]
    for tri in tris:
        values=tri[:,axis]-offset
        if np.min(values)>1e-7 or np.max(values)<-1e-7: continue
        hits=[]
        for i,j in ((0,1),(1,2),(2,0)):
            va,vb=values[i],values[j]
            if abs(va)<1e-7: hits.append(tri[i])
            if va*vb<0: hits.append(tri[i]+va/(va-vb)*(tri[j]-tri[i]))
        if len(hits)<2: continue
        unique=np.unique(np.round(hits,6),axis=0)
        if len(unique)<2: continue
        a,b=max(itertools.combinations(unique,2),key=lambda pair:np.linalg.norm(pair[0]-pair[1]))
        segments.append([[a[coordinates[0]]-origin[0],a[coordinates[1]]-origin[1]],[b[coordinates[0]]-origin[0],b[coordinates[1]]-origin[1]]])
    return segments

def draw_section(ax,axis=1,coordinates=(0,2),module_only=False,origin=(0,0)):
    for part in PARTS:
        if module_only and part['id']=='01_band_silicone':continue
        lines=section_segments(CACHE[part['id']],axis,0,coordinates,origin)
        color=INK if part['id'] in ('01_band_silicone','02_base_shell','10_top_cap') else part['color']
        ax.add_collection(LineCollection(lines,colors=color,linewidths=.85))

fig=plt.figure(figsize=(16.54,11.69),dpi=210);fig.patch.set_facecolor('white')
fig.add_artist(Rectangle((.018,.02),.964,.96,transform=fig.transFigure,fill=False,edgecolor=INK,linewidth=1))
fig.text(.042,.947,'DIVE BUDDY ALERT BAND',fontsize=22,weight='bold',color=INK)
fig.text(.042,.921,'Display assembly · parametric concept layout',fontsize=12,color=MUTED)
fig.text(.958,.949,'DBA-001  |  REV D',ha='right',fontsize=13,weight='bold',color=INK)
fig.text(.958,.924,'Nominal mm · views not to scale · concept by Rafael',ha='right',fontsize=9,color=MUTED)

# Module top outline is derived from named parameters; inner dashed outline is the active-area proposal.
ax=fig.add_axes([.055,.55,.40,.31]);prepare(ax,'A   MODULE TOP',(-29,32),(-21,24))
L,W,H=P['MOD_L'],P['MOD_W'],P['MOD_H']
rrect(ax,-L/2,-W/2,L,W,P['MOD_R'],fill=False,ec=INK,lw=1.1)
rrect(ax,P['DISPLAY_X']-P['WINDOW_L']/2,-P['WINDOW_W']/2,P['WINDOW_L'],P['WINDOW_W'],P['WINDOW_R'],fill=True,fc='#e2ebef',ec=INK,lw=.9)
rrect(ax,P['DISPLAY_X']-P['ACTIVE_L']/2,-P['ACTIVE_W']/2,P['ACTIVE_L'],P['ACTIVE_W'],.5,fill=False,ec=DIM,lw=.7,ls='--')
ax.add_patch(Circle((P['BTN_X'],P['BTN_Y']),P['BTN_STEM_D']/2,fill=True,fc='#f4d4cb',ec=INK,lw=.9))
ax.add_patch(Circle((P['BTN_X'],P['BTN_Y']),P['BTN_D']/2,fill=False,ec=MUTED,lw=.6,ls='--'))
dimension(ax,(-L/2,W/2),(L/2,W/2),f'{L:g} housing',3)
dimension(ax,(L/2,-W/2),(L/2,W/2),f'{W:g}',4,True)
ax.text(P['DISPLAY_X'],0,'13',ha='center',va='center',fontsize=11,color=DIM,weight='bold')
ax.text(P['BTN_X'],0,'11',ha='center',va='center',fontsize=11,color=INK,weight='bold')
ax.text(-L/2,-W/2-5,f"Window {P['WINDOW_L']:g} × {P['WINDOW_W']:g} · active area {P['ACTIVE_L']:g} × {P['ACTIVE_W']:g}",fontsize=8,color=MUTED)

# Exact triangle/plane intersections from regenerated STLs; no old hand-positioned components.
ax=fig.add_axes([.54,.56,.40,.28]);prepare(ax,'B   MODULE CENTER SECTION · Y = 0',(-29,33),(-5,25))
draw_section(ax,module_only=True,origin=(0,P['Z0']))
dimension(ax,(-L/2,0),(-L/2,H),f'{H:g} housing',-4,True)
dimension(ax,(L/2,0),(L/2,P['BASE_H']),f"{P['BASE_H']:g} base",4,True)
for part_id,label in [('12_display_body','12'),('13_display_window','13'),('08_inductive_coil','08'),('14_button_plunger','14'),('07_battery_lipo','07')]:
    part=next(p for p in PARTS if p['id']==part_id);b=part['bbox'];x=(b['xmin']+b['xmax'])/2;z=(b['zmin']+b['zmax'])/2-P['Z0']
    # Numbers beside fine-thickness parts prevent the digits obscuring the section.
    if label=='13': ax.annotate(label,(x,z),(x-8,z+5),fontsize=8,color=DIM,arrowprops=dict(arrowstyle='-',color=DIM,lw=.6))
    elif label=='08': ax.annotate(label,(x+6,z),(x+15,z+3),fontsize=8,color=DIM,arrowprops=dict(arrowstyle='-',color=DIM,lw=.6))
    elif label=='14': ax.annotate(label,(x,z),(x+17,z-1),fontsize=8,color=DIM,arrowprops=dict(arrowstyle='-',color=DIM,lw=.6))
    else: ax.text(x,z,label,ha='center',va='center',fontsize=7,color=DIM,weight='bold')
ax.text(-L/2,-4,f"{P['MEMBRANE_T']:g} membrane · {P['SHELL_T']:g} nominal wall · {P['BTN_H']:g} button protrusion",fontsize=8,color=MUTED)

ax=fig.add_axes([.06,.17,.40,.29]);prepare(ax,'C   BAND CENTER SECTION · Y = 0',(-44,48),(-45,62))
draw_section(ax)
b=DATA['assembly_bbox'];overall=b['zmax']-b['zmin'];od=P['BAND_ID']+2*P['BAND_T']
dimension(ax,(-P['BAND_ID']/2,0),(P['BAND_ID']/2,0),f"Ø{P['BAND_ID']:g} relaxed",0)
dimension(ax,(-od/2,-od/2),(od/2,-od/2),f'Ø{od:g} band OD',-5)
dimension(ax,(od/2,b['zmin']),(od/2,b['zmax']),f'{overall:g} overall',5,True)

ax=fig.add_axes([.54,.17,.39,.29]);prepare(ax,'D   AXIAL CENTER SECTION · X = 0',(-27,31),(-45,62))
draw_section(ax,axis=0,coordinates=(1,2))
dimension(ax,(-P['BAND_W']/2,-od/2),(P['BAND_W']/2,-od/2),f"{P['BAND_W']:g} band width",-5)
cradle_width=P['MOD_W']+2*P['CRADLE_MARGIN']
dimension(ax,(-cradle_width/2,P['CRADLE_TOP']),(cradle_width/2,P['CRADLE_TOP']),f'{cradle_width:g} cradle',5)
ax.text(-24,-23,'Sections taken through the\nregenerated CAD mesh.',fontsize=8,color=MUTED)

fig.add_artist(matplotlib.lines.Line2D([.04,.96],[.135,.135],transform=fig.transFigure,color='#bdc9cf',lw=.7))
fig.text(.043,.113,'07  Battery envelope     08  Inductive coil     11  Top button     12  Display body     13  Display window     14  Plunger',fontsize=9,color=INK)
notes=[
'Concept geometry only. Nominal envelopes are unselected; production tolerances, connections, retention and sealing details remain unresolved.',
'Inductive charging through the sealed-cap concept; no charging port. Rounded perimeter seal geometry is an envelope, not a released gland.',
'No depth rating, measured range, battery runtime or manufacturing readiness is established. Dimensions regenerate from dba_cad.py and design-data.json.'
]
for i,note in enumerate(notes):fig.text(.043,.092-i*.019,note,fontsize=8.2,color=MUTED)
fig.savefig(OUT/'DBA-001_drawing_sheet.png',facecolor='white')
fig.savefig(OUT/'DBA-001_drawing_sheet.pdf',facecolor='white')
print('Rev D DBA-001 PNG/PDF ready; sections derived from regenerated STL files.')
