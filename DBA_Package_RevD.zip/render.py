"""Regenerate Rev D concept renders from the current STL set and design-data.json."""
from pathlib import Path
import json
import vtk
from vtk.util.numpy_support import vtk_to_numpy
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import proj3d
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from stl import mesh as stlmesh

ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'design-data.json').read_text())
CAD,OUT=ROOT/'cad',ROOT/'renders'; OUT.mkdir(exist_ok=True)
PARTS=DATA['parts']; PARAMS=DATA['parameters']
plt.rcParams['font.family']='DejaVu Sans'
EXTERIOR={'01_band_silicone','02_base_shell','10_top_cap','11_button_dome','13_display_window'}
LIGHT=np.array([0.4,-0.6,0.7]); LIGHT/=np.linalg.norm(LIGHT)
CACHE={p['id']:stlmesh.Mesh.from_file(str(CAD/(p['id']+'.stl'))).vectors.copy() for p in PARTS}

def shade(triangles,base):
    normals=np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0])
    normals/=np.linalg.norm(normals,axis=1,keepdims=True)+1e-9
    light=np.clip(normals@LIGHT,0,1)
    rgb=np.array(matplotlib.colors.to_rgb(base))
    return np.clip(.50*rgb+.67*rgb*light[:,None]+.10*light[:,None]**12,0,1)

def scene(ax,explode=False,elev=30,azim=-55,subset=None,zoom=1.05):
    points,triangles,colors=[],[],[]
    e,a=np.radians(elev),np.radians(azim)
    viewpoint=np.array([np.cos(e)*np.cos(a),np.cos(e)*np.sin(a),np.sin(e)])
    for part in PARTS:
        if subset and part['id'] not in subset: continue
        t=CACHE[part['id']].copy()
        if explode: t[:,:,2]+=part['dz']
        points.append(t.reshape(-1,3))
        n=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]); t=t[n@viewpoint>0]
        triangles.append(t); colors.append(shade(t,part['color']))
    t=np.vstack(triangles); c=np.vstack(colors)
    collection=Poly3DCollection(t,facecolors=c,edgecolors=c,linewidths=.15,zsort='average')
    ax.add_collection3d(collection)
    points=np.vstack(points); lo=points.min(0); hi=points.max(0); extent=hi-lo; pad=.04*extent.max()
    ax.set_xlim(lo[0]-pad,hi[0]+pad); ax.set_ylim(lo[1]-pad,hi[1]+pad); ax.set_zlim(lo[2]-pad,hi[2]+pad)
    ax.set_box_aspect(tuple(extent+2*pad),zoom=zoom); ax.view_init(elev=elev,azim=azim)
    ax.set_proj_type('ortho'); ax.set_axis_off()


def vtk_scene(width,height,elev,azim,subset=None,explode=False,bg='#081621'):
    renderer=vtk.vtkRenderer(); renderer.SetBackground(*matplotlib.colors.to_rgb(bg))
    bounds=[]
    for part in PARTS:
        if subset and part['id'] not in subset: continue
        reader=vtk.vtkSTLReader(); reader.SetFileName(str(CAD/(part['id']+'.stl')))
        normals=vtk.vtkPolyDataNormals(); normals.SetInputConnection(reader.GetOutputPort())
        normals.ComputePointNormalsOn(); normals.SplittingOn(); normals.SetFeatureAngle(38); normals.ConsistencyOn()
        mapper=vtk.vtkPolyDataMapper(); mapper.SetInputConnection(normals.GetOutputPort()); mapper.ScalarVisibilityOff()
        actor=vtk.vtkActor(); actor.SetMapper(mapper)
        prop=actor.GetProperty(); prop.SetColor(*matplotlib.colors.to_rgb(part['color']))
        prop.SetInterpolationToPhong(); prop.SetAmbient(.32); prop.SetDiffuse(.68)
        prop.SetSpecular(.28 if part['id']!='01_band_silicone' else .08); prop.SetSpecularPower(38)
        if explode: actor.SetPosition(0,0,part['dz'])
        renderer.AddActor(actor)
        box=part['bbox']; points=np.array([[box[k+'min'] for k in ('x','y','z')],[box[k+'max'] for k in ('x','y','z')]])
        if explode: points[:,2]+=part['dz']
        bounds.append(points)
    points=np.vstack(bounds); center=(points.min(0)+points.max(0))/2; extent=points.max(0)-points.min(0)
    e,a=np.radians(elev),np.radians(azim)
    direction=np.array([np.cos(e)*np.cos(a),np.cos(e)*np.sin(a),np.sin(e)])
    camera=renderer.GetActiveCamera(); camera.SetPosition(*(center+direction*np.linalg.norm(extent)*3))
    camera.SetFocalPoint(*center); camera.SetViewUp(*(0,1,0) if abs(elev)>89 else (0,0,1)); camera.ParallelProjectionOn()
    window=vtk.vtkRenderWindow(); window.SetOffScreenRendering(1); window.SetSize(width,height); window.SetMultiSamples(8); window.AddRenderer(renderer)
    renderer.ResetCamera(); camera.SetParallelScale(camera.GetParallelScale()*.89)
    window.Render()
    capture=vtk.vtkWindowToImageFilter(); capture.SetInput(window); capture.ReadFrontBufferOff(); capture.Update()
    image=capture.GetOutput(); rgb=vtk_to_numpy(image.GetPointData().GetScalars()).reshape(height,width,-1)[::-1].copy()
    anchors={}
    for part in PARTS:
        box=part['bbox']; point=[(box[k+'min']+box[k+'max'])/2 for k in ('x','y','z')]
        if explode: point[2]+=part['dz']
        renderer.SetWorldPoint(*point,1); renderer.WorldToDisplay(); x,y,z=renderer.GetDisplayPoint(); anchors[part['id']]=(x/width,y/height)
    window.Finalize(); return rgb,anchors


def save_scene(name,size,elev,azim,subset,bg='#081621'):
    image,_=vtk_scene(int(size[0]*220),int(size[1]*220),elev,azim,subset,bg=bg)
    plt.imsave(OUT/name,image)


def main():
    save_scene('hero_assembled.png',(8,7),34,-55,EXTERIOR)
    save_scene('hero_low.png',(8,7),16,30,EXTERIOR)
    save_scene('module_top.png',(7,7),62,-70,EXTERIOR-{'01_band_silicone'},'#ffffff')
    fig=plt.figure(figsize=(10,13),dpi=220); fig.patch.set_facecolor('#f4f6f7')
    image,projected=vtk_scene(650,1250,17,-65,explode=True,bg='#f4f6f7')
    ax=fig.add_axes([.015,.08,.57,.83]); ax.imshow(image); ax.axis('off'); fig.canvas.draw()
    position=ax.get_position(); anchors=[]
    for part in PARTS:
        x,y=projected[part['id']]
        anchors.append((part,position.x0+x*position.width,position.y0+y*position.height))
    for k,(part,fx,fy) in enumerate(sorted(anchors,key=lambda item:-item[2])):
        target=.895-k*.058
        fig.add_artist(matplotlib.lines.Line2D([fx,.56,.65],[fy,target,target],transform=fig.transFigure,color=part['color'],lw=.9))
        fig.add_artist(matplotlib.patches.Circle((fx,fy),.004,transform=fig.transFigure,fc=part['color'],ec='white',lw=.6))
        fig.text(.66,target,part['id'][:2],va='center',fontsize=9,weight='bold',color=part['color'])
        fig.text(.697,target,part['label'],va='center',fontsize=8.6,color='#172c3b')
    fig.text(.04,.971,'DIVE BUDDY ALERT BAND',fontsize=17,weight='bold',color='#172c3b')
    fig.text(.04,.947,'Rev D · exploded concept assembly · 14 generated parts',fontsize=10,color='#4f6371')
    fig.text(.04,.02,'Component envelopes are unselected. Separation is illustrative; dimensions are nominal millimetres.',fontsize=8.5,color='#4f6371')
    fig.savefig(OUT/'exploded_annotated.png',facecolor=fig.get_facecolor()); plt.close(fig)
    fig=plt.figure(figsize=(12,4.5),dpi=220); fig.patch.set_facecolor('white')
    for i,(elev,azim,label) in enumerate([(0,-90,'FRONT'),(0,0,'SIDE'),(90,-90,'TOP · DISPLAY + BUTTON')]):
        image,_=vtk_scene(800,800,elev,azim,EXTERIOR,bg='#ffffff')
        ax=fig.add_subplot(1,3,i+1); ax.imshow(image); ax.axis('off')
        ax.set_title(label,fontsize=10,color='#172c3b')
    fig.subplots_adjust(.01,.02,.99,.90,wspace=.04)
    fig.savefig(OUT/'ortho_sheet.png',facecolor='white'); plt.close(fig)
    print('Current STL renders ready: '+', '.join(p.name for p in OUT.glob('*.png')))

if __name__=='__main__': main()
