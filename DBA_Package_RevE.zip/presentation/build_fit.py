from pathlib import Path
import json, math, copy
from xml.etree import ElementTree as ET
P=Path(__file__).resolve().parent
k=json.loads((P.parent/'design-data.json').read_text())['parameters']
s=(P/'fit-template.svg').read_text().replace('__ID__',f"{k['BAND_ID']:g}").replace('__CIRC__',str(round(math.pi*k['BAND_ID'])))
(P/'fit.svg').write_text(s)
ns='http://www.w3.org/2000/svg';ET.register_namespace('',ns)
desktop=ET.fromstring(s);mobile=ET.Element('{'+ns+'}svg',{'width':'360','height':'662','viewBox':'0 0 360 662','role':'img','aria-label':'Relaxed silicone band and illustrative flex. No rated extension.'})
def el(tag,attrs,text=None):
 n=ET.SubElement(mobile,'{'+ns+'}'+tag,attrs);n.text=text;return n
el('rect',{'width':'360','height':'662','fill':'#f3f7fa'})
mobile.append(copy.deepcopy(desktop.find('{'+ns+'}defs')))
def text(x,y,words,size=18,bold=False):
 return el('text',{'x':str(x),'y':str(y),'font-family':'Helvetica,Arial,sans-serif','font-size':str(size),'fill':'#183449','text-anchor':'middle','font-weight':'bold' if bold else 'normal'},words)
text(180,35,'Flexible silicone.',24,True);text(180,64,'Rigid sealed module.',21)
groups=desktop.find('{'+ns+'}g').findall('{'+ns+'}g')
for i,g in enumerate(groups):
 g=copy.deepcopy(g);g.set('font-family','Helvetica,Arial,sans-serif');g.set('fill','#183449');g.set('transform',f'translate(180 {215 if i==0 else 492}) scale(.82)')
 for t in g.findall('{'+ns+'}text'):
  t.set('font-size','21');t.text=f"{k['BAND_ID']:g} mm opening" if i==0 else 'Illustrative flex'
 mobile.append(g)
text(180,321,'At rest',21,True);text(180,349,f"Approx. {round(math.pi*k['BAND_ID'])} mm around the inside",16)
text(180,589,'Intended to stretch over the hand',17,True)
text(180,623,'Size coverage is not established.',15)
text(180,646,'Illustration, not a material simulation.',15)
(P/'fit-mobile.svg').write_text(ET.tostring(mobile,encoding='unicode'))
print('Generated fit illustration from current relaxed band dimensions.')
