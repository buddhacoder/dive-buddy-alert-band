(() => {
  const root = document.getElementById('dba-presentation-hub');
  const data = JSON.parse(document.getElementById('dba-hub-data').textContent);
  const get = id => root.querySelector('#' + id);
  let collection = 'slides';
  const positions = {slides: 0, drawings: 0};
  const preview = get('dba-preview');
  const picker = get('dba-page');
  const previous = get('dba-previous');
  const next = get('dba-next');
  const documentLink = get('dba-document');
  function render() {
    const pages = data[collection], index = positions[collection], page = pages[index];
    get('dba-image-error').hidden = true;
    preview.hidden = false;
    preview.alt = page.text.join(' ');
    preview.src = page.image;
    get('dba-full-view').href = page.full;
    get('dba-counter').textContent = `${index + 1} / ${pages.length}`;
    previous.disabled = index === 0;
    next.disabled = index === pages.length - 1;
    picker.replaceChildren(...pages.map((item, i) => {
      const option = document.createElement('option');
      option.value = i;
      option.textContent = `${i + 1}. ${item.title}`;
      return option;
    }));
    picker.value = index;
    get('dba-page-text').replaceChildren(...page.text.map(text => {
      const p = document.createElement('p'); p.textContent = text; return p;
    }));
    documentLink.href = data.base + (collection === 'slides' ? 'DBA_Product_Overview_RevE.pptx' : 'DBA_Annotated_Views_RevD.pdf');
    documentLink.textContent = collection === 'slides' ? 'Download PowerPoint' : 'Open drawings PDF';
  }
  function move(delta) {
    positions[collection] = Math.min(data[collection].length - 1, Math.max(0, positions[collection] + delta));
    render();
  }
  root.querySelectorAll('[data-collection]').forEach(button => button.addEventListener('click', () => {
    const selected = button.dataset.collection;
    root.querySelectorAll('[data-collection]').forEach(b => b.setAttribute('aria-pressed', String(b === button)));
    get('dba-browse').hidden = selected === 'downloads';
    get('dba-downloads').hidden = selected !== 'downloads';
    if (selected !== 'downloads') { collection = selected; render(); }
  }));
  previous.addEventListener('click', () => move(-1));
  next.addEventListener('click', () => move(1));
  picker.addEventListener('change', () => { positions[collection] = Number(picker.value); render(); });
  root.addEventListener('keydown', event => {
    if (get('dba-browse').hidden || /SELECT|INPUT|TEXTAREA/.test(event.target.tagName)) return;
    if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
      event.preventDefault(); move(event.key === 'ArrowRight' ? 1 : -1);
    }
  });
  preview.addEventListener('error', () => { preview.hidden = true; get('dba-image-error').hidden = false; });
  render();
})();
