// Shared display-only normal smoothing. Vertex coordinates and mesh payloads remain unchanged.
window.DBA_smoothNormals=function(g){
 g.computeVertexNormals();const p=g.attributes.position,n=g.attributes.normal,buckets=new Map();
 for(let i=0;i<p.count;i++){const k=[p.getX(i),p.getY(i),p.getZ(i)].map(v=>Math.round(v*10000)).join(',');if(!buckets.has(k))buckets.set(k,[]);buckets.get(k).push(i);}
 const out=new Float32Array(n.array.length);
 for(const ids of buckets.values())for(const i of ids){let x=0,y=0,z=0;for(const j of ids){if(n.getX(i)*n.getX(j)+n.getY(i)*n.getY(j)+n.getZ(i)*n.getZ(j)>.65){x+=n.getX(j);y+=n.getY(j);z+=n.getZ(j);}}const l=Math.hypot(x,y,z)||1;out[i*3]=x/l;out[i*3+1]=y/l;out[i*3+2]=z/l;}
 g.setAttribute('normal',new THREE.BufferAttribute(out,3));
};
(function(){
 const root=document.documentElement;
 const motion=matchMedia('(prefers-reduced-motion: reduce)');
 const gauge=document.getElementById('depthGauge');
 const reading=document.getElementById('depthReading');
 // This scale belongs to the scrolling presentation, not the device specification.
 const presentationDepth=30;
 let queued=false,lastReading=-1;
 if(gauge){gauge.hidden=false;document.body.classList.add('has-depth-gauge');}
 function update(){
  queued=false;
  const max=Math.max(1,root.scrollHeight-innerHeight);
  const progress=Math.min(1,Math.max(0,scrollY/max));
  const metres=Math.round(progress*presentationDepth);
  root.style.setProperty('--descent',progress);
  root.style.setProperty('--light',1-progress*.9);
  root.style.setProperty('--water-top',`rgb(${Math.round(17-progress*14)},${Math.round(60-progress*49)},${Math.round(77-progress*53)})`);
  root.style.setProperty('--water-bottom',`rgb(${Math.round(7-progress*4)},${Math.round(28-progress*21)},${Math.round(43-progress*26)})`);
  root.style.setProperty('--particle-shift',motion.matches?'0px':`${-progress*140}px`);
  if(gauge&&metres!==lastReading){
   reading.textContent=String(metres).padStart(2,'0');
   gauge.setAttribute('aria-label',`Presentation scroll depth: ${metres} metres below sea level. Illustrative, not a device reading.`);
   lastReading=metres;
  }
 }
 function schedule(){if(!queued){queued=true;requestAnimationFrame(update);}}
 addEventListener('scroll',schedule,{passive:true});
 addEventListener('resize',schedule);
 addEventListener('pageshow',schedule);
 motion.addEventListener('change',schedule);
 // Expanded specifications, loaded images and restored anchors change page length.
 if('ResizeObserver' in window)new ResizeObserver(schedule).observe(document.body);
 update();
})();
